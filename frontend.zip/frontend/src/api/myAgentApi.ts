export type Agent = {
  id: string;
  name: string;
  logo: string;
  category: string;
  description: string;
  performance: number;
  subscribers: number;
  activeUsers: number;
  avgResponseTime: number;
  uptime: number;
  errorRate: number;
  rating: number;
  reviews: { user: string; text: string; rating: number }[];
  trending: boolean;
  createdAt: string;
  lastActive: string;
  backendUrl: string;
  embedUrl?: string;
  capabilities: string[];
  publisher?: string;
  status: "active" | "retired";
};

export async function getAgents(): Promise<Agent[]> {
  const res = await fetch("http://localhost:8000/agents");
  if (!res.ok) throw new Error("Failed to fetch agents");
  return res.json();
}

export async function getActiveAgents(): Promise<Agent[]> {
  const res = await fetch("http://localhost:8000/agents/public");
  if (!res.ok) throw new Error("Failed to fetch agents");
  return res.json();
}

export async function retireAgent(agentId: string, action: "retire" | "unretire", token: string) {
  const res = await fetch(`http://localhost:8000/agents/retire/${agentId}`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ action }),
  });
  if (!res.ok) throw new Error("Failed to update agent status");
  return await res.json();
}

export async function getAgentById(id: string): Promise<Agent | undefined> {
  const res = await fetch(`http://localhost:8000/agents/${id}`);
  if (!res.ok) return undefined;
  return res.json();
}

export async function subscribeAgent(agentId: string, token: string) {
  const res = await fetch(`http://localhost:8000/agents/subscribe/${agentId}`, {
    method: "POST",
    headers: { "Authorization": `Bearer ${token}` }
  });
  if (!res.ok) throw new Error("Failed to subscribe");
  return await res.json();
}

export async function unsubscribeAgent(agentId: string, token: string) {
  const res = await fetch(`http://localhost:8000/agents/unsubscribe/${agentId}`, {
    method: "POST",
    headers: { "Authorization": `Bearer ${token}` }
  });
  if (!res.ok) throw new Error("Failed to unsubscribe");
  return await res.json();
}

// Optional: fetch only subscribed agents (active only)
export async function getSubscribedAgents(token: string) {
  const res = await fetch("http://localhost:8000/agents/my-subscribed", {
    headers: { "Authorization": `Bearer ${token}` }
  });
  if (!res.ok) throw new Error("Failed to fetch subscribed agents");
  return await res.json();
}
