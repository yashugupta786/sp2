// src/api/requestedAgentsApi.ts
export type RequestedAgentStatus = "open" | "claimed" | "in_progress" | "fulfilled";
export type RequestedAgent = {
  id: string;
  name: string;
  description: string;
  useCase: string;
  expectedKPIs?: string;
  requestedBy?: string;
  requestedAt: string;
  status: RequestedAgentStatus;
  claimedBy?: string;
  claimedAt?: string;
  fulfilledBy?: string;
  fulfilledAt?: string;
  statusHistory?: {
    status: RequestedAgentStatus;
    by?: string;
    at: string;
    note?: string;
  }[];
};

const BASE = "http://localhost:8000/requested-agents";
function getAuth() {
  const token = localStorage.getItem("token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function getRequestedAgents(): Promise<RequestedAgent[]> {
  const res = await fetch(`${BASE}/`, { headers: getAuth() });
  if (!res.ok) throw new Error("Failed to fetch requests");
  return await res.json();
}

export async function addRequestedAgent(agent: Omit<RequestedAgent, "id" | "requestedAt" | "status" | "statusHistory">): Promise<RequestedAgent> {
  const res = await fetch(`${BASE}/`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...getAuth() },
    body: JSON.stringify(agent)
  });
  if (!res.ok) throw new Error("Failed to add request");
  return await res.json();
}

export async function claimRequestedAgent(id: string, _devEmail?: string) {
  const res = await fetch(`${BASE}/claim/${id}`, { method: "POST", headers: getAuth() });
  return res.ok;
}
export async function setRequestedAgentInProgress(id: string, _devEmail?: string) {
  const res = await fetch(`${BASE}/in_progress/${id}`, { method: "POST", headers: getAuth() });
  return res.ok;
}
export async function fulfillRequestedAgent(id: string, _devEmail?: string) {
  const res = await fetch(`${BASE}/fulfill/${id}`, { method: "POST", headers: getAuth() });
  return res.ok;
}
