import React, { useState } from "react";
import { motion } from "framer-motion";

type Props = {
  onSubmit: (email: string, password: string, name: string) => void;
  loading?: boolean;
  error?: string;
};

const SignupForm: React.FC<Props> = ({ onSubmit, loading = false, error }) => {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [touched, setTouched] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);
    if (email && password && name) {
      onSubmit(email, password, name);
    }
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="bg-white rounded-xl shadow-xl p-8 w-full max-w-md flex flex-col gap-6 border"
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="text-center text-3xl font-bold text-primary mb-4">Create your AgentPath account</div>
      {error && (
        <div className="bg-red-100 text-red-700 rounded p-2 mb-2 text-center text-sm">{error}</div>
      )}
      <div className="flex flex-col gap-2">
        <label className="font-semibold">Name</label>
        <input
          type="text"
          value={name}
          disabled={loading}
          onChange={(e) => setName(e.target.value)}
          className={`px-4 py-3 border rounded focus:outline-primary bg-gray-50 ${touched && !name ? 'border-red-400' : ''}`}
          placeholder="Your Name"
          required
        />
      </div>
      <div className="flex flex-col gap-2">
        <label className="font-semibold">Email</label>
        <input
          type="email"
          value={email}
          disabled={loading}
          onChange={(e) => setEmail(e.target.value)}
          className={`px-4 py-3 border rounded focus:outline-primary bg-gray-50 ${touched && !email ? 'border-red-400' : ''}`}
          placeholder="you@email.com"
          required
        />
      </div>
      <div className="flex flex-col gap-2">
        <label className="font-semibold">Password</label>
        <input
          type="password"
          value={password}
          disabled={loading}
          onChange={(e) => setPassword(e.target.value)}
          className={`px-4 py-3 border rounded focus:outline-primary bg-gray-50 ${touched && !password ? 'border-red-400' : ''}`}
          placeholder="********"
          required
        />
      </div>
      <button
        type="submit"
        className="w-full py-3 mt-4 rounded-lg bg-primary text-white font-semibold hover:bg-agent transition"
        disabled={loading}
      >
        {loading ? "Signing up..." : "Sign up"}
      </button>
      <div className="text-center text-gray-500 text-sm mt-2">
        Already have an account?{" "}
        <a href="/login" className="text-primary font-semibold hover:underline">
          Login
        </a>
      </div>
    </motion.form>
  );
};

export default SignupForm;
