import React from "react";
import type { Agent } from "../../api/myAgentApi";
import { StarIcon, UserGroupIcon, ArrowTrendingUpIcon } from "@heroicons/react/24/solid";

type Props = {
  agent: Agent;
  showAll?: boolean; // show all metrics or just summary
};

const badge = "rounded-full px-3 py-1 text-xs font-semibold";
const label = "text-gray-500 text-xs font-medium";

const AgentKPIs: React.FC<Props> = ({ agent, showAll }) => (
  <div className="flex flex-wrap gap-3 items-center mt-2">
    <span className={`${badge} bg-blue-50 text-blue-600 flex items-center gap-1`}>
      <UserGroupIcon className="h-4 w-4" /> {agent.subscribers} subs
    </span>
    <span className={`${badge} bg-emerald-50 text-emerald-700`}>
      Perf: <span className="font-bold">{agent.performance}%</span>
    </span>
    <span className={`${badge} bg-orange-50 text-orange-700`}>
      RT: {agent.avgResponseTime} ms
    </span>
    <span className={`${badge} bg-yellow-50 text-yellow-700`}>
      Uptime: {agent.uptime}%
    </span>
    <span className={`${badge} bg-rose-50 text-rose-700`}>
      Errors: {agent.errorRate}%
    </span>
    <span className={`${badge} bg-green-50 text-green-700 flex items-center gap-1`}>
      <StarIcon className="h-4 w-4" /> {agent.rating}
    </span>
    {showAll && (
      <>
        <span className={`${badge} bg-purple-50 text-purple-700`}>
          Active: {agent.activeUsers}
        </span>
        <span className={`${badge} bg-slate-100 text-slate-700`}>
          <ArrowTrendingUpIcon className="h-4 w-4" /> Trending: {agent.trending ? "Yes" : "No"}
        </span>
        <span className={label}>
          Created: {agent.createdAt}
        </span>
        <span className={label}>
          Last Active: {agent.lastActive}
        </span>
      </>
    )}
  </div>
);

export default AgentKPIs;
