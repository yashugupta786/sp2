import React from "react";
import type { Agent } from "../../api/myAgentApi";
import { FireIcon } from "@heroicons/react/24/solid";
import AgentKPIs from "./AgentKPIs";
import { Link, useNavigate } from "react-router-dom";

type Props = {
  agent: Agent;
  onSubscribe?: (id: string) => void;
  isSubscribed?: boolean;
  onUnsubscribe?: (id: string) => void;
};

const AgentCard: React.FC<Props> = ({ agent, onSubscribe, isSubscribed, onUnsubscribe }) => {
  const navigate = useNavigate();

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 flex flex-col gap-3 border hover:scale-[1.02] transition-all duration-200 relative">
      <div className="flex items-center gap-3">
        <img
          src={agent.logo}
          alt={agent.name}
          className="h-12 w-12 rounded-full border"
        />
        <div>
          <Link
            to={`/agents/${agent.id}`}
            className="text-xl font-bold hover:underline transition-colors"
          >
            {agent.name}
          </Link>
          <div className="text-xs bg-blue-100 text-blue-700 rounded px-2 py-0.5 inline-block mt-1">
            {agent.category}
          </div>
        </div>
        {agent.trending && (
          <FireIcon
            className="h-5 w-5 text-orange-400 absolute top-3 right-3 animate-pulse"
            title="Trending"
          />
        )}
      </div>
      <div className="text-gray-600 text-sm mb-2">{agent.description}</div>

      <AgentKPIs agent={agent} />

      {/* View Details and Subscribe/Unsubscribe Buttons */}
      <div className="flex gap-2 mt-2">
        <button
          onClick={() => navigate(`/agents/${agent.id}`)}
          className="w-1/2 py-2 rounded border border-primary text-primary font-semibold hover:bg-blue-50 transition"
        >
          View Details
        </button>
        {!isSubscribed ? (
          <button
            className="w-1/2 py-2 rounded bg-primary text-white font-semibold hover:bg-agent transition"
            onClick={() => onSubscribe && onSubscribe(agent.id)}
          >
            Subscribe
          </button>
        ) : (
          <button
            className="w-1/2 py-2 rounded bg-red-100 text-red-600 font-semibold hover:bg-red-400 hover:text-white transition"
            onClick={() => onUnsubscribe && onUnsubscribe(agent.id)}
          >
            Unsubscribe
          </button>
        )}
      </div>
    </div>
  );
};

export default AgentCard;
