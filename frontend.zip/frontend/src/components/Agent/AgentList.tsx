import React from "react";
import type { Agent } from "../../api/myAgentApi";
import AgentCard from "./AgentCard";

type Props = {
  agents: Agent[];
  onSubscribe?: (id: string) => void;
  subscribedAgentIds?: string[];
  onUnsubscribe?: (id: string) => void;
};

const AgentList: React.FC<Props> = ({ agents, onSubscribe, subscribedAgentIds = [], onUnsubscribe }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    {agents.map(agent => (
      <AgentCard
        key={agent.id}
        agent={agent}
        onSubscribe={onSubscribe}
        isSubscribed={subscribedAgentIds.includes(agent.id)}
        onUnsubscribe={onUnsubscribe}
      />
    ))}
  </div>
);

export default AgentList;
