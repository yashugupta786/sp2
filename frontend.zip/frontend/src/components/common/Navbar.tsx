import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../lib/AuthContext";

const Navbar = () => {
  const location = useLocation();
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  // Highlight active tab
  const isActive = (path: string) =>
    location.pathname === path
      ? "text-primary font-bold underline underline-offset-4"
      : "";

  // Handle logout
  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="flex items-center justify-between px-10 py-4 bg-white shadow-sm">
      {/* Logo and brand as one big home link */}
      <Link to="/" className="flex items-center gap-3 hover:opacity-90 transition">
        <img src="/logo.svg" alt="AgentPath" className="h-10" />
        <span className="text-3xl font-extrabold text-primary tracking-tight">AgentPath</span>
      </Link>
      <nav className="flex items-center gap-6">
<Link to="/hireagents" className={`font-semibold hover:text-primary transition ${isActive("/hireagents")}`}>Hire Agents</Link>
        <Link to="/agents" className={`font-semibold hover:text-primary transition ${isActive("/agents")}`}>Agents</Link>
        <Link to="/my-agents" className={`font-semibold hover:text-primary transition ${isActive("/my-agents")}`}>My Agents</Link>
        <Link to="/publish-agent" className={`font-semibold hover:text-primary transition ${isActive("/publish-agent")}`}>Publish Agent</Link>
        <Link to="/requested-agents" className={`font-semibold hover:text-primary transition ${isActive("/requested-agents")}`}>Requested Agents</Link>
  <Link to="/" className={`font-semibold hover:text-primary transition ${isActive("/")}`}>How it works</Link>
      </nav>
      <div className="flex items-center gap-3">
        {/* Show Admin Dashboard if user is admin */}
        {user?.is_admin && (
          <Link
            to="/admin"
            className="font-semibold text-primary rounded hover:bg-primary hover:text-white transition px-4 py-2"
          >
            Admin Dashboard
          </Link>
        )}
        {!user ? (
          <>
            <Link
              to="/login"
              className="font-semibold text-primary rounded hover:bg-primary hover:text-white transition px-4 py-2"
            >
              Login
            </Link>
            <Link
              to="/signup"
              className="font-semibold bg-primary text-white rounded hover:bg-primary-light transition px-4 py-2"
            >
              Signup
            </Link>
          </>
        ) : (
          <>
            <span className="font-semibold text-gray-600 mr-2 hidden md:inline">
              Welcome, {user.name?.split(" ")[0]}
            </span>
            <button
              onClick={handleLogout}
              className="font-semibold rounded bg-red-50 text-red-600 border border-red-200 hover:bg-red-600 hover:text-white transition px-4 py-2"
            >
              Logout
            </button>
          </>
        )}
      </div>
    </header>
  );
};

export default Navbar;
