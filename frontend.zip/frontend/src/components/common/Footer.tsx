const Footer = () => (
  <footer className="py-6 bg-white text-center text-gray-500 text-sm border-t">
    © {new Date().getFullYear()} AgentPath. Built for the AI enterprise era.
  </footer>
);

export default Footer;
