import React from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "./lib/AuthContext";

// Import all your pages
import Home from "./pages/Home";
import Agents from "./pages/Agents";
import MyAgents from "./pages/MyAgents";
import PublishAgent from "./pages/PublishAgent";
import AgentDetail from "./pages/AgentDetail";
import TryAgent from "./pages/TryAgent";
import ApiCurl from "./pages/ApiCurl";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import AdminDashboard from "./pages/AdminDashboard";
import RequestAgent from "./pages/RequestAgent";
import RequestedAgents from "./pages/RequestedAgents";
import HowItWorks from "./pages/HowItWorks";


// Helper: Protected route logic
function ProtectedRoute({ children, adminOnly = false }: { children: React.ReactNode; adminOnly?: boolean }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <div>Loading...</div>; // <--- Loader on route level, optional
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (adminOnly && !user.is_admin) return <Navigate to="/" />;
  return <>{children}</>;
}

const AppRoutes = () => (
  <Routes>
    {/* Public */}
    <Route path="/login" element={<Login />} />
    <Route path="/signup" element={<Signup />} />

    {/* Protected: logged in users only */}
    <Route
      path="/"
      element={
        <ProtectedRoute>
          <HowItWorks />
        </ProtectedRoute>
      }
    />
    {/* Old Home = Hire Agents */}
    <Route
      path="/hireagents"
      element={
        <ProtectedRoute>
          <Home />
        </ProtectedRoute>
      }
    />
    <Route
      path="/agents"
      element={
        <ProtectedRoute>
          <Agents />
        </ProtectedRoute>
      }
    />
    <Route
      path="/my-agents"
      element={
        <ProtectedRoute>
          <MyAgents />
        </ProtectedRoute>
      }
    />
    <Route
      path="/publish-agent"
      element={
        <ProtectedRoute>
          <PublishAgent />
        </ProtectedRoute>
      }
    />
    <Route
      path="/agents/:id"
      element={
        <ProtectedRoute>
          <AgentDetail />
        </ProtectedRoute>
      }
    />
    {/* <--- THIS HANDLES ALL 'Try this Agent' clicks for ANY agent, including PMO */}
    <Route
      path="/agents/:id/try"
      element={
        <ProtectedRoute>
          <TryAgent />
        </ProtectedRoute>
      }
    />
    <Route
      path="/agents/:id/api"
      element={
        <ProtectedRoute>
          <ApiCurl />
        </ProtectedRoute>
      }
    />
    <Route
  path="/how-it-works"
  element={
    <ProtectedRoute>
      <HowItWorks />
    </ProtectedRoute>
  }
/>

    <Route
      path="/request-agent"
      element={
        <ProtectedRoute>
          <RequestAgent />
        </ProtectedRoute>
      }
    />
    <Route
      path="/requested-agents"
      element={
        <ProtectedRoute>
          <RequestedAgents />
        </ProtectedRoute>
      }
    />
    {/* Admin only */}
    <Route
      path="/admin"
      element={
        <ProtectedRoute adminOnly>
          <AdminDashboard />
        </ProtectedRoute>
      }
    />

    {/* Catch-all: Redirect to / if unknown route */}
    <Route path="*" element={<Navigate to="/" />} />
  </Routes>
);

const App = () => (
  <AuthProvider>
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  </AuthProvider>
);

export default App;
