import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import { getAgentById } from "../api/myAgentApi";

const AgentApi = () => {
  const { id } = useParams();
  const [agent, setAgent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    getAgentById(id!).then(data => {
      setAgent(data || null);
      setLoading(false);
    });
  }, [id]);

  // Mock token generation
  const handleGenerateToken = () => {
    setToken("sk-12345-demo-token-for-copy");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <div className="flex-1 flex items-center justify-center text-xl text-primary animate-pulse">
          Loading API details...
        </div>
        <Footer />
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <div className="flex-1 flex items-center justify-center text-2xl text-red-600">
          Agent not found.
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex-1 flex flex-col items-center justify-center py-10 px-4">
        <div className="max-w-2xl w-full bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-2xl font-bold mb-4 text-primary">
            API & cURL Access for <span className="text-agent">{agent.name}</span>
          </h1>
          <div className="mb-4">
            <div className="font-semibold mb-2">Your API Token</div>
            {token ? (
              <div className="flex items-center gap-2">
                <span className="bg-gray-100 px-3 py-1 rounded font-mono text-xs">{token}</span>
                <button
                  className="py-1 px-3 rounded bg-primary text-white font-semibold hover:bg-agent transition text-xs"
                  onClick={() => {
                    navigator.clipboard.writeText(token);
                  }}
                >
                  Copy
                </button>
              </div>
            ) : (
              <button
                className="py-2 px-6 rounded bg-agent text-white font-semibold hover:bg-primary transition"
                onClick={handleGenerateToken}
              >
                Generate API Token
              </button>
            )}
          </div>
          <div className="mb-4">
            <div className="font-semibold mb-2">Example cURL Request</div>
            <pre className="bg-slate-100 rounded p-4 text-sm overflow-x-auto">
              {`curl -X POST \\
  '${agent.backendUrl}' \\
  -H 'Authorization: Bearer ${token || "<YOUR_TOKEN_HERE>"}' \\
  -H 'Content-Type: application/json' \\
  -d '{"input": "Your query or data"}'
`}
            </pre>
          </div>
          <div className="mb-2">
            <div className="font-semibold mb-2">How to Use</div>
            <ol className="list-decimal ml-5 text-sm text-gray-600">
              <li>Generate your API token above.</li>
              <li>Send POST requests to the API endpoint shown above.</li>
              <li>Include your token in the <b>Authorization</b> header.</li>
              <li>Input/output details depend on the agent’s capability.</li>
            </ol>
          </div>
          <div className="mt-6 text-center">
            <Link
              to={`/agents/${agent.id}`}
              className="inline-block py-2 px-6 rounded bg-primary text-white font-semibold hover:bg-agent transition"
            >
              &larr; Back to Agent
            </Link>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default AgentApi;
