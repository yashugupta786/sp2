import { getAgents } from "../api/myAgentApi";
import type { Agent } from "../api/myAgentApi";

console.log("TestImport loaded");
console.log("Agent type is:", Agent); // Should be 'undefined' (because types are erased at runtime)
getAgents().then(res => console.log("Agents array:", res));

export default function TestImport() {
  return <div>Test Import Page</div>;
}
