import React, { useState } from "react";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import { addRequestedAgent } from "../api/requestedAgentsApi";

const RequestAgent = () => {
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | undefined>();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [useCase, setUseCase] = useState("");
  const [expectedKPIs, setExpectedKPIs] = useState("");
  const [requestedBy, setRequestedBy] = useState(""); // Optional: email/name

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !description || !useCase) {
      setError("Please fill in all required fields.");
      return;
    }
    setError(undefined);
    setLoading(true);

    addRequestedAgent({
      name,
      description,
      useCase,
      expectedKPIs,
      requestedBy,
    }).then(() => {
      setLoading(false);
      setSubmitted(true);
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex flex-1 flex-col items-center justify-center py-10 px-4">
        <div className="max-w-lg w-full bg-white rounded-xl shadow-xl p-8">
          <h1 className="text-2xl font-bold mb-4 text-center text-primary">
            Request a New Agent
          </h1>
          {submitted ? (
            <div className="text-green-600 text-center text-lg">
              ✅ Your request has been submitted!
              <br />Our team will review and make it visible in the Requested Agents tab.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <input
                className="border rounded px-4 py-2"
                placeholder="Agent Name *"
                value={name}
                onChange={e => setName(e.target.value)}
                required
              />
              <textarea
                className="border rounded px-4 py-2"
                placeholder="Describe what the agent should do *"
                value={description}
                onChange={e => setDescription(e.target.value)}
                required
              />
              <textarea
                className="border rounded px-4 py-2"
                placeholder="Describe your use case *"
                value={useCase}
                onChange={e => setUseCase(e.target.value)}
                required
              />
              <input
                className="border rounded px-4 py-2"
                placeholder="Expected KPIs (optional)"
                value={expectedKPIs}
                onChange={e => setExpectedKPIs(e.target.value)}
              />
              <input
                className="border rounded px-4 py-2"
                placeholder="Your email (optional)"
                value={requestedBy}
                onChange={e => setRequestedBy(e.target.value)}
              />
              {error && (
                <div className="text-red-600 text-sm">{error}</div>
              )}
              <button
                className="mt-2 py-2 rounded bg-primary text-white font-semibold hover:bg-agent transition"
                type="submit"
                disabled={loading}
              >
                {loading ? "Submitting..." : "Submit Request"}
              </button>
            </form>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default RequestAgent;
