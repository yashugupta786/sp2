import React, { useEffect, useState } from "react";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import AgentList from "../components/Agent/AgentList";
import { getActiveAgents, subscribeAgent, unsubscribeAgent, getSubscribedAgents } from "../api/myAgentApi"; // <--- updated import
import type { Agent } from "../api/myAgentApi";
import { Link } from "react-router-dom";
import { useAuth } from "../lib/AuthContext";

const Agents = () => {
  const { token } = useAuth();
  const [agents, setAgents] = useState<Agent[]>([]);
  const [subscribedIds, setSubscribedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getActiveAgents().then(setAgents); // <--- show only active (non-retired) agents
    if (token) {
      getSubscribedAgents(token).then(subs => setSubscribedIds(subs.map((a: Agent) => a.id)));
    }
    setLoading(false);
  }, [token]);

  const handleSubscribe = async (id: string) => {
    if (!token) return alert("Please login to subscribe.");
    try {
      await subscribeAgent(id, token);
      setSubscribedIds([...subscribedIds, id]);
    } catch {
      alert("Subscribe failed");
    }
  };

  const handleUnsubscribe = async (id: string) => {
    if (!token) return alert("Please login to unsubscribe.");
    try {
      await unsubscribeAgent(id, token);
      setSubscribedIds(subscribedIds.filter(i => i !== id));
    } catch {
      alert("Unsubscribe failed");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex flex-1 flex-col items-center py-10 px-4 max-w-7xl mx-auto w-full">
        <div className="text-3xl font-extrabold mb-6 text-primary text-center">
          Explore the AI Agent Store
        </div>
        {loading ? (
          <div className="text-lg text-gray-400 mt-16">Loading agents...</div>
        ) : (
          <>
            <AgentList
              agents={agents}
              onSubscribe={handleSubscribe}
              subscribedAgentIds={subscribedIds}
              onUnsubscribe={handleUnsubscribe}
            />
            {/* CTA Button to Request Agent */}
            <Link to="/request-agent">
              <button className="mt-12 py-3 px-8 rounded-xl bg-agent text-white font-semibold shadow hover:bg-primary hover:scale-105 transition-all text-lg">
                Didn’t find your agent? Request one!
              </button>
            </Link>
          </>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default Agents;
