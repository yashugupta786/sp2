// src/pages/RequestedAgents.tsx

import React, { useEffect, useState } from "react";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import {
  getRequestedAgents,
  claimRequestedAgent,
  setRequestedAgentInProgress,
  fulfillRequestedAgent,
} from "../api/requestedAgentsApi";
import type { RequestedAgent, RequestedAgentStatus } from "../api/requestedAgentsApi";
import { useAuth } from "../lib/AuthContext"; // import Auth context

const STATUS_COLORS: Record<RequestedAgentStatus, string> = {
  open: "bg-blue-50 text-blue-800",
  claimed: "bg-orange-50 text-orange-700",
  in_progress: "bg-yellow-50 text-yellow-700",
  fulfilled: "bg-green-50 text-green-700",
};

const RequestedAgents = () => {
  const [agents, setAgents] = useState<RequestedAgent[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const { user } = useAuth();
  const devEmail = user?.email ?? "";

  // Tabs are dynamic to use user email
  const TABS = [
    { label: "All", filter: () => true },
    { label: "Unclaimed", filter: (a: RequestedAgent) => a.status === "open" },
    { label: "Claimed by Me", filter: (a: RequestedAgent) => a.claimedBy === devEmail },
    { label: "Fulfilled", filter: (a: RequestedAgent) => a.status === "fulfilled" },
  ];

  useEffect(() => {
    refresh();
    // eslint-disable-next-line
  }, []);

  function refresh() {
    setLoading(true);
    getRequestedAgents().then((data) => {
      setAgents(data);
      setLoading(false);
    });
  }

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 1700);
  }

  async function handleClaim(id: string) {
    const res = await claimRequestedAgent(id);
    if (res) {
      showToast("Claimed successfully!");
      refresh();
    }
  }
  async function handleInProgress(id: string) {
    const res = await setRequestedAgentInProgress(id);
    if (res) {
      showToast("Marked as In Progress");
      refresh();
    }
  }
  async function handleFulfill(id: string) {
    const res = await fulfillRequestedAgent(id);
    if (res) {
      showToast("Marked as Fulfilled 🎉");
      refresh();
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex-1 flex flex-col items-center px-4 py-10">
        <div className="w-full max-w-5xl bg-white rounded-xl shadow-xl p-8">
          <h1 className="text-3xl font-bold mb-6 text-primary text-center">
            Requested Agents Marketplace
          </h1>
          {/* Tabs */}
          <div className="flex gap-3 mb-6 justify-center">
            {TABS.map((tab, i) => (
              <button
                key={tab.label}
                className={`px-4 py-2 rounded font-semibold border-b-2 ${
                  activeTab === i
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-600 hover:text-primary"
                }`}
                onClick={() => setActiveTab(i)}
              >
                {tab.label}
              </button>
            ))}
          </div>
          {/* Table */}
          {loading ? (
            <div className="text-center text-lg text-primary animate-pulse">Loading...</div>
          ) : agents.length === 0 ? (
            <div className="text-lg text-center text-gray-500">No agent requests yet.</div>
          ) : (
            <table className="min-w-full bg-white border text-sm">
              <thead>
                <tr className="bg-blue-50">
                  <th className="py-2 px-4 border">Name</th>
                  <th className="py-2 px-4 border">Description</th>
                  <th className="py-2 px-4 border">Use Case</th>
                  <th className="py-2 px-4 border">Requested By</th>
                  <th className="py-2 px-4 border">Requested At</th>
                  <th className="py-2 px-4 border">Status</th>
                  <th className="py-2 px-4 border">Action</th>
                </tr>
              </thead>
              <tbody>
                {agents
                  .filter(TABS[activeTab].filter)
                  .map((agent) => (
                  <tr key={agent.id}>
                    <td className="py-2 px-4 border font-semibold">{agent.name}</td>
                    <td className="py-2 px-4 border">{agent.description}</td>
                    <td className="py-2 px-4 border">{agent.useCase}</td>
                    <td className="py-2 px-4 border">{agent.requestedBy || "-"}</td>
                    <td className="py-2 px-4 border">{agent.requestedAt}</td>
                    <td className={`py-2 px-4 border capitalize`}>
                      <span className={`px-2 py-0.5 rounded ${STATUS_COLORS[agent.status]}`}>
                        {agent.status.replace("_", " ")}
                      </span>
                      {agent.claimedBy && (
                        <span className="block text-xs mt-1 text-gray-500">by {agent.claimedBy}</span>
                      )}
                    </td>
                    <td className="py-2 px-4 border">
                      {/* Action Buttons */}
                      {agent.status === "open" && (
                        <button
                          className="px-3 py-1 rounded bg-primary text-white font-semibold hover:bg-agent transition"
                          onClick={() => handleClaim(agent.id)}
                        >
                          Claim
                        </button>
                      )}
                      {agent.status === "claimed" && agent.claimedBy === devEmail && (
                        <button
                          className="px-3 py-1 rounded bg-yellow-500 text-white font-semibold hover:bg-yellow-600 transition"
                          onClick={() => handleInProgress(agent.id)}
                        >
                          In Progress
                        </button>
                      )}
                      {agent.status === "in_progress" && agent.claimedBy === devEmail && (
                        <button
                          className="px-3 py-1 rounded bg-green-500 text-white font-semibold hover:bg-green-600 transition"
                          onClick={() => handleFulfill(agent.id)}
                        >
                          Fulfill
                        </button>
                      )}
                      {agent.status === "fulfilled" && (
                        <span className="text-green-600 font-semibold">Fulfilled</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {/* Toast */}
          {toast && (
            <div className="fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-2 bg-primary text-white rounded shadow font-semibold transition-all z-40">
              {toast}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default RequestedAgents;
