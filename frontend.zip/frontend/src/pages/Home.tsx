import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Lottie from "lottie-react";
import animationData from "../assets/agent-hero.json";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import { Link } from "react-router-dom";
import AgentList from "../components/Agent/AgentList";
import { getAgents, subscribeAgent, unsubscribeAgent, getSubscribedAgents } from "../api/myAgentApi";
import type { Agent } from "../api/myAgentApi";
import { useAuth } from "../lib/AuthContext";

const Home = () => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Agent[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [subscribedAgentIds, setSubscribedAgentIds] = useState<string[]>([]);
  const { user, token } = useAuth();

  // Fetch subscribed agents if logged in
  useEffect(() => {
    if (token) {
      getSubscribedAgents(token)
        .then((agents: Agent[]) => setSubscribedAgentIds(agents.map(a => a.id)))
        .catch(() => setSubscribedAgentIds([]));
    } else {
      setSubscribedAgentIds([]);
    }
  }, [token]);

  // For demo, use a simple filter; swap with LLM-powered backend later.
  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    setResults(null);
    const agents = await getAgents();
    // Mock "LLM" search: matches in name/description/category, case-insensitive
    const filtered = agents.filter(
      agent =>
        agent.name.toLowerCase().includes(query.toLowerCase()) ||
        agent.description.toLowerCase().includes(query.toLowerCase()) ||
        agent.category.toLowerCase().includes(query.toLowerCase())
    );
    setTimeout(() => {
      setResults(filtered);
      setLoading(false);
    }, 800);
  };

  // --- Handlers for Subscribe/Unsubscribe
  const handleSubscribe = async (agentId: string) => {
    if (!token) return alert("Login to subscribe!");
    try {
      await subscribeAgent(agentId, token);
      setSubscribedAgentIds(ids => [...ids, agentId]);
    } catch {
      alert("Failed to subscribe.");
    }
  };

  const handleUnsubscribe = async (agentId: string) => {
    if (!token) return alert("Login to unsubscribe!");
    try {
      await unsubscribeAgent(agentId, token);
      setSubscribedAgentIds(ids => ids.filter(id => id !== agentId));
    } catch {
      alert("Failed to unsubscribe.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1 flex flex-col items-center justify-center px-4 pt-20 pb-8">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="flex flex-col items-center w-full"
        >
          <div className="w-72 md:w-96">
            <Lottie animationData={animationData} loop={true} />
          </div>
          <h1 className="text-5xl font-bold mb-4 text-center text-primary">
            Discover, Hire & Retire <span className="text-agent">AI Agents</span>
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl text-center mb-8">
            The all-in-one marketplace for enterprise-ready AI agents. Find the perfect agent, track their performance, and manage their lifecycle—all in one platform.
          </p>
          <motion.form
            onSubmit={handleSearch}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="w-full max-w-lg"
          >
            <div className="flex rounded-xl shadow-md overflow-hidden border bg-white">
              <input
                type="text"
                className="flex-1 px-5 py-3 text-lg outline-none"
                placeholder="🔍 Search for an AI agent (e.g., document summarizer, HR assistant)..."
                value={query}
                onChange={e => setQuery(e.target.value)}
              />
              <button type="submit" className="px-6 bg-primary text-white font-semibold flex items-center gap-2 hover:bg-agent transition">
                Search
              </button>
            </div>
          </motion.form>
          {/* Results */}
          <div className="w-full max-w-5xl mt-8">
            {loading && (
              <div className="text-xl text-center text-primary mt-8 animate-pulse">
                Searching agents...
              </div>
            )}
            {results && (
              results.length > 0 ? (
                <AgentList
                  agents={results}
                  onSubscribe={handleSubscribe}
                  onUnsubscribe={handleUnsubscribe}
                  subscribedAgentIds={subscribedAgentIds}
                />
              ) : (
                <div className="flex flex-col items-center mt-12">
                  <span className="text-xl font-semibold text-primary mb-2">
                    😕 No matching agents found.
                  </span>
                  <Link to="/request-agent">
                    <button className="mt-2 py-2 px-6 rounded bg-agent text-white font-semibold shadow hover:bg-primary hover:scale-105 transition-all text-lg">
                      Didn’t find your agent? Request one!
                    </button>
                  </Link>
                </div>
              )
            )}
          </div>
        </motion.div>
      </main>
      <Footer />
    </div>
  );
};

export default Home;
