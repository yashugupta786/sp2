import React, { useState } from "react";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import { useNavigate } from "react-router-dom";

const AGENT_CATEGORIES = [
  "Finance", "HR", "Legal", "Research", "Healthcare", "Support", "Operations", "Custom"
];
const AGENT_CAPABILITIES = [
  "Summarization", "Chatbot", "Q&A", "Classification", "Extraction", "Custom"
];

function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(" ");
}

const Helper = ({ children }: { children: React.ReactNode }) => (
  <span className="ml-1 text-xs text-gray-400">{children}</span>
);

const AgentPreviewCard = ({
  name, category, logo, description, capabilities, tryEndpoint, apiEndpoint
}: {
  name: string,
  category: string,
  logo: string | null,
  description: string,
  capabilities: string[],
  tryEndpoint: string,
  apiEndpoint: string,
}) => (
  <div className="rounded-xl shadow-xl bg-white p-6 w-full max-w-md mx-auto mt-8 border border-gray-200">
    <div className="flex items-center gap-3 mb-2">
      <img src={logo || "/logo.svg"} alt={name || "Agent Logo"} className="h-12 w-12 rounded-full border" />
      <div>
        <div className="text-xl font-bold">{name || "Agent Name"}</div>
        <div className="text-xs bg-blue-100 text-blue-700 rounded px-2 py-0.5 inline-block mt-1">{category || "Category"}</div>
      </div>
    </div>
    <div className="text-gray-600 text-sm mb-2">{description || "Agent description will appear here..."}</div>
    <div className="flex gap-2 flex-wrap mb-2">
      {capabilities.length ? capabilities.map(cap => (
        <span key={cap} className="bg-agent/10 text-agent px-2 py-0.5 rounded">{cap}</span>
      )) : <span className="text-xs text-gray-400">No capabilities added</span>}
    </div>
    <div className="mt-3 text-xs">
      <div><b>Try Agent Endpoint:</b> {tryEndpoint || <span className="text-gray-300">[none]</span>}</div>
      <div><b>API & cURL Endpoint:</b> {apiEndpoint || <span className="text-gray-300">[none]</span>}</div>
    </div>
  </div>
);

const PublishAgent = () => {
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [capabilities, setCapabilities] = useState<string[]>([]);
  const [description, setDescription] = useState("");
  const [logo, setLogo] = useState<string | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [tryEndpoint, setTryEndpoint] = useState("");
  const [apiEndpoint, setApiEndpoint] = useState("");
  const [embedUrl, setEmbedUrl] = useState("");
  const [kpis, setKpis] = useState("");
  const [sampleInput, setSampleInput] = useState("");
  const [sampleOutput, setSampleOutput] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | undefined>();
  const [showPreview, setShowPreview] = useState(false);
  const navigate = useNavigate();

  // Logo file preview & base64 conversion
  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.length) {
      const file = e.target.files[0];
      setLogoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setLogo(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleCapabilitiesChange = (cap: string) => {
    setCapabilities(prev =>
      prev.includes(cap)
        ? prev.filter(c => c !== cap)
        : [...prev, cap]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !category || capabilities.length === 0 || !description || !tryEndpoint || !apiEndpoint) {
      setError("Please fill all required fields (name, category, at least one capability, description, Try Endpoint, API Endpoint)");
      return;
    }
    setError(undefined);
    setShowPreview(true);
  };

  // Final "publish" after preview
  const handleFinalPublish = async () => {
    setShowPreview(false);
    setLoading(true);
    try {
      // Prepare payload for backend
      const payload = {
        name,
        category,
        capabilities,
        description,
        logo: logo || "/logo.svg",
        backendUrl: apiEndpoint,
        embedUrl,
        tryEndpoint,
        kpis,
        sampleInput,
        sampleOutput,
        isPublic,
        // Optionals/defaults (backend fills most defaults, including id/publisher)
      };

      const token = localStorage.getItem("token");
      const res = await fetch("http://localhost:8000/agents/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.detail || "Failed to publish agent");
      }

      setLoading(false);
      setSubmitted(true);
      setError(undefined);
      setTimeout(() => navigate("/agents"), 1800);
    } catch (err: any) {
      setLoading(false);
      setError(err?.message || "Failed to publish agent");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex-1 flex flex-col items-center justify-center py-10 px-2">
        <div className="w-full max-w-3xl bg-white rounded-xl shadow-xl p-10">
          <h1 className="text-3xl font-bold mb-8 text-center text-primary">Publish a New AI Agent</h1>
          {submitted ? (
            <div className="text-green-600 text-center text-lg animate-fade-in">
              🎉 Your agent is live in the marketplace!
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-5 items-start">
              {/* LEFT */}
              <div className="flex flex-col gap-4">
                <div>
                  <label className="font-semibold text-primary">
                    Agent Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    className="border rounded px-4 py-2 w-full mt-1"
                    placeholder="E.g. HR Buddy, Contract AI"
                    value={name}
                    maxLength={40}
                    onChange={e => setName(e.target.value)}
                    required
                  />
                  <Helper>This name will appear as the agent’s display name.</Helper>
                </div>
                <div>
                  <label className="font-semibold text-primary">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    className="border rounded px-4 py-2 w-full mt-1"
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    required
                  >
                    <option value="">Select Category</option>
                    {AGENT_CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                  <Helper>Pick the category that best fits your agent.</Helper>
                </div>
                <div>
                  <div className="font-semibold text-primary mb-1">
                    Capabilities <span className="text-red-500">*</span>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    {AGENT_CAPABILITIES.map(cap => (
                      <label key={cap} className="flex items-center gap-1 text-sm">
                        <input
                          type="checkbox"
                          checked={capabilities.includes(cap)}
                          onChange={() => handleCapabilitiesChange(cap)}
                          className="accent-primary"
                        />
                        <span>{cap}</span>
                      </label>
                    ))}
                  </div>
                  <Helper>Select at least one. These describe what your agent can do.</Helper>
                </div>
                <div>
                  <label className="font-semibold text-primary">
                    Description <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    className="border rounded px-4 py-2 w-full mt-1 resize-y"
                    placeholder="Describe what your agent does, target users, and benefits."
                    value={description}
                    rows={5}
                    onChange={e => setDescription(e.target.value)}
                    required
                  />
                  <Helper>Short, clear value prop is best. Example: “Summarizes contracts and flags risky clauses for legal teams.”</Helper>
                </div>
                <div>
                  <label className="font-semibold text-primary">Agent Logo (optional)</label>
                  <input
                    className="border rounded px-4 py-2 w-full mt-1"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoChange}
                  />
                  <Helper>JPG/PNG, ideally 1:1 aspect, 128x128+. Max 1MB.</Helper>
                </div>
              </div>
              {/* RIGHT */}
              <div className="flex flex-col gap-4">
                <div>
                  <label className="font-semibold text-primary">
                    Try Agent Endpoint <span className="text-red-500">*</span>
                  </label>
                  <input
                    className="border rounded px-4 py-2 w-full mt-1"
                    placeholder="https://api.yourdomain.com/agents/hr-buddy/try"
                    value={tryEndpoint}
                    onChange={e => setTryEndpoint(e.target.value)}
                    required
                  />
                  <Helper>This is used for the “Try this Agent” live demo.</Helper>
                </div>
                <div>
                  <label className="font-semibold text-primary">
                    API & cURL Endpoint <span className="text-red-500">*</span>
                  </label>
                  <input
                    className="border rounded px-4 py-2 w-full mt-1"
                    placeholder="https://api.yourdomain.com/agents/hr-buddy"
                    value={apiEndpoint}
                    onChange={e => setApiEndpoint(e.target.value)}
                    required
                  />
                  <Helper>Endpoint used for API access and sample cURL requests.</Helper>
                </div>
                <div>
                  <label className="font-semibold text-primary">Embed URL </label><span className="text-red-500">*</span>
                  <input
                    className="border rounded px-4 py-2 w-full mt-1"
                    placeholder="https://demo.yourdomain.com/hr-buddy"
                    value={embedUrl}
                    onChange={e => setEmbedUrl(e.target.value)}
                  />
                  <Helper>For embedding your agent UI (iframe). Leave blank if not needed.</Helper>
                </div>
                <div>
                  <label className="font-semibold text-primary">KPIs (optional)</label>
                  <input
                    className="border rounded px-4 py-2 w-full mt-1"
                    placeholder="e.g. Accuracy, Speed, Uptime"
                    value={kpis}
                    onChange={e => setKpis(e.target.value)}
                  />
                  <Helper>Comma-separated. These help users compare agents.</Helper>
                </div>
                <div>
                  <label className="font-semibold text-primary">Sample Input (optional)</label>
                  <input
                    className="border rounded px-4 py-2 w-full mt-1"
                    placeholder='e.g. {"text": "Summarize this contract..."}'
                    value={sampleInput}
                    onChange={e => setSampleInput(e.target.value)}
                  />
                </div>
                <div>
                  <label className="font-semibold text-primary">Sample Output (optional)</label>
                  <input
                    className="border rounded px-4 py-2 w-full mt-1"
                    placeholder='e.g. {"summary": "This contract..."}'
                    value={sampleOutput}
                    onChange={e => setSampleOutput(e.target.value)}
                  />
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <input
                    type="checkbox"
                    checked={isPublic}
                    onChange={e => setIsPublic(e.target.checked)}
                    className="accent-primary"
                    id="publicCheckbox"
                  />
                  <label htmlFor="publicCheckbox" className="text-sm text-gray-600">
                    Make this agent public (listed in the marketplace)
                  </label>
                </div>
                <div className="flex-1 flex flex-col justify-end">
                  {error && <div className="text-red-600 text-sm mb-2">{error}</div>}
                  <button
                    className={classNames(
                      "mt-2 py-3 rounded bg-primary text-white font-semibold hover:bg-agent transition w-full text-lg",
                      loading && "opacity-50 cursor-not-allowed"
                    )}
                    type="submit"
                    disabled={loading}
                  >
                    {loading ? "Publishing..." : "Preview & Publish"}
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Live preview card (on desktop) */}
          {!submitted && (
            <div className="hidden md:block">
              <AgentPreviewCard
                name={name}
                category={category}
                logo={logo}
                description={description}
                capabilities={capabilities}
                tryEndpoint={tryEndpoint}
                apiEndpoint={apiEndpoint}
              />
            </div>
          )}

          {/* Preview Modal */}
          {showPreview && (
            <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
              <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full">
                <h2 className="text-xl font-bold mb-4 text-primary text-center">Preview Your Agent</h2>
                <AgentPreviewCard
                  name={name}
                  category={category}
                  logo={logo}
                  description={description}
                  capabilities={capabilities}
                  tryEndpoint={tryEndpoint}
                  apiEndpoint={apiEndpoint}
                />
                <div className="flex gap-3 justify-center mt-8">
                  <button
                    className="py-2 px-6 rounded bg-primary text-white font-semibold hover:bg-agent transition"
                    onClick={handleFinalPublish}
                  >
                    {loading ? "Publishing..." : "Publish"}
                  </button>
                  <button
                    className="py-2 px-6 rounded bg-gray-200 text-gray-700 font-semibold hover:bg-gray-300 transition"
                    onClick={() => setShowPreview(false)}
                  >
                    Edit
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
      <Footer />
    </div>
  );
};

export default PublishAgent;
