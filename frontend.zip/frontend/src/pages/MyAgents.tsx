import React, { useState, useEffect } from "react";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import { Link } from "react-router-dom";
import { getSubscribedAgents, unsubscribeAgent } from "../api/myAgentApi";
import { useAuth } from "../lib/AuthContext"; // get token/user

const MyAgents = () => {
  const { token } = useAuth();
  const [myAgents, setMyAgents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) return;
    getSubscribedAgents(token)
      .then(setMyAgents)
      .finally(() => setLoading(false));
  }, [token]);

  const handleUnsubscribe = async (id: string) => {
    if (!token) return;
    try {
      await unsubscribeAgent(id, token);
      setMyAgents(myAgents.filter(a => a.id !== id));
    } catch {
      alert("Unsubscribe failed");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex flex-1 flex-col items-center px-4 py-10">
        <div className="w-full max-w-4xl">
          <h1 className="text-3xl font-bold mb-6 text-primary text-center">
            My Subscribed Agents
          </h1>
          {loading ? (
            <div className="text-xl text-primary animate-pulse text-center mt-16">
              Loading...
            </div>
          ) : myAgents.length === 0 ? (
            <div className="text-lg text-center mt-10 text-gray-500">
              You haven’t subscribed to any agents yet.
              <div className="mt-4">
                <Link
                  to="/agents"
                  className="py-2 px-6 rounded bg-primary text-white font-semibold hover:bg-agent transition"
                >
                  Explore Agents
                </Link>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {myAgents.map(agent => (
                <div key={agent.id} className="bg-white shadow-xl rounded-xl p-6 flex flex-col gap-3">
                  <div className="flex items-center gap-4 mb-2">
                    <img src={agent.logo} alt={agent.name} className="h-12 w-12 rounded-full border" />
                    <div>
                      <div className="text-xl font-bold">{agent.name}</div>
                      <div className="text-xs bg-blue-100 text-blue-700 rounded px-2 py-0.5 inline-block">
                        {agent.category}
                      </div>
                    </div>
                  </div>
                  <div className="text-gray-600 text-sm mb-2">{agent.description}</div>
                  <div className="flex gap-2 mb-2 flex-wrap">
                    {agent.capabilities.map((cap: string) => (
                      <span key={cap} className="bg-agent/10 text-agent px-2 py-0.5 rounded">{cap}</span>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-auto">
                    <Link
                      to={`/agents/${agent.id}/try`}
                      className="py-2 px-4 rounded bg-agent text-white font-semibold hover:bg-primary transition"
                    >
                      Try this Agent
                    </Link>
                    <Link
                      to={`/agents/${agent.id}/api`}
                      className="py-2 px-4 rounded bg-primary text-white font-semibold hover:bg-agent transition"
                    >
                      API & cURL
                    </Link>
                    <button
                      onClick={() => handleUnsubscribe(agent.id)}
                      className="py-2 px-4 rounded bg-red-100 text-red-600 font-semibold hover:bg-red-400 hover:text-white transition"
                    >
                      Unsubscribe
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default MyAgents;
