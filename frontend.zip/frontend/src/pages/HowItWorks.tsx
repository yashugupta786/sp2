import React from "react";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";

// Add some inline CSS for key animations
const animatedArrowStyle: React.CSSProperties = {
  animation: "arrowBounce 1.2s infinite",
};
const animatedPulseStyle: React.CSSProperties = {
  animation: "pulseGlow 1.5s infinite",
};

const steps = [
  {
    title: "1. Discover Agents",
    icon: "🔎",
    narrative:
      "Browse a rich marketplace of AI-powered business agents. Need a PMO specialist? An HR Buddy? Or a Finance wizard? Instantly discover agents ready to work for you.",
    benefit: "No job posts, no interviews. Discovery is instant!",
  },
  {
    title: "2. Hire Instantly",
    icon: "🤖",
    narrative:
      "Click 'Subscribe' and your agent is ready to join your team. Onboard skills and expertise with one tap. No onboarding, no paperwork, no downtime.",
    benefit: "Expertise on tap. Zero onboarding time.",
  },
  {
    title: "3. Assign Work",
    icon: "📄",
    narrative:
      "Assign your business tasks—upload a BRD, a resume, an invoice, or a case file. Set your goals, and let your agent do the heavy lifting.",
    benefit: "Delegate repetitive work. Focus on decisions, not grunt work.",
  },
  {
    title: "4. Get Instant Results",
    icon: "⚡",
    narrative:
      "Your agent analyzes, processes, and delivers structured outputs: milestones, summaries, scores, recommendations—whatever you need.",
    benefit: "Business results in seconds. No manual follow-ups.",
  },
  {
    title: "5. Review & Iterate",
    icon: "🔁",
    narrative:
      "See outputs, tweak inputs, and keep iterating as your needs evolve. Each cycle gets you closer to business perfection.",
    benefit: "Agile improvement, built in.",
  },
  {
    title: "6. Retire Agents",
    icon: "🏁",
    narrative:
      "When the job is done, retire the agent instantly. No fixed costs. No overheads. Hire again only when you need.",
    benefit: "On-demand workforce. Total control.",
  },
];

const HowItWorks: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-white to-blue-100">
      <Navbar />

      {/* HERO */}
      <section className="py-14 px-4 flex flex-col items-center justify-center">
        <h1 className="text-5xl md:text-6xl font-extrabold mb-4 text-center tracking-tight">
          How <span className="text-primary drop-shadow-lg">AgentPath</span> Works
        </h1>
        <p className="text-xl md:text-2xl text-gray-700 text-center max-w-3xl font-semibold mb-2">
          The Fastest Way to <span className="text-primary">Hire, Use, and Retire</span> Business AI Agents.
        </p>
        <p className="text-lg text-gray-600 text-center max-w-2xl mb-7">
          Imagine a world where business expertise is always available, <b>instantly on-demand</b>. No interviews, no onboarding, no contracts. <br />
          <span className="bg-blue-100 text-blue-900 px-3 py-1 rounded-lg mt-2 inline-block font-bold">
            Hire &nbsp;→&nbsp; Assign &nbsp;→&nbsp; Automate &nbsp;→&nbsp; Review &nbsp;→&nbsp; Retire
          </span>
        </p>
      </section>

      {/* ANIMATED BUSINESS FLOW */}
      <section className="flex flex-col items-center py-2">
        <div className="flex flex-row flex-wrap justify-center items-center gap-0 md:gap-1 mb-5 overflow-x-auto">
          {steps.map((step, idx) => (
            <React.Fragment key={step.title}>
              <div
                className="flex flex-col items-center mx-2"
                style={idx === 1 ? animatedPulseStyle : {}}
              >
                <div
                  className={`rounded-full shadow-lg border-2 border-blue-200 mb-1 w-16 h-16 flex items-center justify-center text-4xl select-none bg-white`}
                >
                  {step.icon}
                </div>
                <div className="text-xs font-semibold text-gray-600 text-center w-24">{step.title.split(". ")[1]}</div>
              </div>
              {/* Animated Arrow (skip after last step) */}
              {idx !== steps.length - 1 && (
                <span
                  className="mx-2 md:mx-0 text-blue-400 text-2xl md:text-3xl"
                  style={animatedArrowStyle}
                  aria-hidden
                >
                  →
                </span>
              )}
            </React.Fragment>
          ))}
        </div>
        <div className="text-lg text-blue-900 font-bold text-center mt-3 mb-1 tracking-wide animate-fade-in-up">
          <span className="text-primary">AgentPath</span> enables a business cycle you control: Hire ➔ Assign ➔ Automate ➔ Review ➔ Retire
        </div>
      </section>

      {/* STEP CARDS WITH STORY */}
      <section className="w-full flex flex-wrap justify-center gap-10 px-4 py-10">
        {steps.map((step, idx) => (
          <div
            key={step.title}
            className="bg-white rounded-2xl shadow-lg border-2 border-blue-100 px-8 py-7 max-w-sm min-h-[285px] flex flex-col items-center hover:scale-[1.03] transition-all duration-200 relative"
          >
            <div className={`text-4xl mb-2 ${idx === 1 ? "animate-bounce" : ""}`}>{step.icon}</div>
            <div className="text-lg font-bold text-blue-800 mb-2 text-center">{step.title}</div>
            <div className="text-gray-700 text-center mb-3 font-medium">{step.narrative}</div>
            <div className="absolute bottom-4 left-0 right-0 text-center text-xs text-blue-600 font-semibold italic">
              {step.benefit}
            </div>
          </div>
        ))}
      </section>

      {/* STORYTELLING / BUSINESS IMPACT */}
      <section className="w-full flex flex-col items-center py-10 px-3 bg-gradient-to-t from-blue-50 to-transparent">
        <div className="max-w-4xl bg-white shadow-xl rounded-2xl px-10 py-9 border border-blue-100 text-center animate-fade-in">
          <div className="text-2xl md:text-3xl font-extrabold mb-4 text-primary">Why Agents, Not Apps?</div>
          <div className="text-lg text-gray-800 mb-5">
            <span className="text-primary font-bold">AgentPath</span> changes the way you do business.<br />
            <span className="font-semibold text-blue-900">
              Forget rigid apps and endless SaaS bloat. Hire AI agents with business skills, <u>just like hiring a team member</u>. Assign work, see results, and retire them when done.
            </span>
            <br /><br />
            <span className="text-blue-700 font-semibold">
              <b>Scale up</b> for a project, <b>scale down</b> when done.<br />
              <b>No code, no waiting, zero IT headaches.</b><br />
              Bring <span className="text-primary font-bold">“hire-to-retire”</span> agility to your workflows—<span className="text-green-600 font-bold">without HR, contracts, or compliance hassle.</span>
            </span>
          </div>
          <div className="mt-6 flex flex-col items-center gap-2 text-base text-gray-600">
            <span>💡 <b>Pro Tip:</b> You can run multiple agents for different business tasks—PMO, HR, Finance—side by side!</span>
            <span>🚀 <b>Result:</b> Transform days of manual work into instant results. No more backlogs.</span>
          </div>
        </div>
        <div className="mt-10 text-md text-gray-500 italic text-center">
          <span className="inline-block animate-pulse">⚡ Automate anything. Pay only for what you use. Control every cycle.</span>
        </div>
      </section>

      {/* FINAL CALL TO ACTION */}
      <section className="py-8 flex flex-col items-center">
        <div className="bg-gradient-to-r from-primary to-blue-400 rounded-full px-10 py-5 shadow-lg animate-fade-in-up">
          <span className="text-2xl md:text-3xl font-extrabold text-white drop-shadow">
            Welcome to <span className="underline underline-offset-4">the future of business automation.</span>
          </span>
        </div>
        <div className="mt-5 text-md text-blue-700 text-center max-w-xl">
          Try AgentPath now.<br />
          <b>Hire. Automate. Retire. Repeat.</b>
        </div>
      </section>

      <Footer />

      {/* Keyframes for animation (add once per app!) */}
      <style>{`
        @keyframes arrowBounce {
          0%, 100% { transform: translateY(0);}
          50% { transform: translateY(-8px);}
        }
        @keyframes pulseGlow {
          0%, 100% { box-shadow: 0 0 0 0 #60a5fa33; }
          70% { box-shadow: 0 0 20px 8px #60a5fa33;}
        }
        @keyframes fade-in-up {
          0% { opacity: 0; transform: translateY(16px);}
          100% { opacity: 1; transform: translateY(0);}
        }
        .animate-fade-in-up {
          animation: fade-in-up 1.2s cubic-bezier(0.4,0,0.2,1) both;
        }
        .animate-fade-in {
          animation: fade-in-up 1.5s cubic-bezier(0.4,0,0.2,1) both;
        }
      `}</style>
    </div>
  );
};

export default HowItWorks;