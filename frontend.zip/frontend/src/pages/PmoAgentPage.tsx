import React, { useState } from "react";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import { useParams } from "react-router-dom";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";

// ----- Types for PMO Output -----
type PMOResponse = {
  project_overview: string;
  start_date: string;
  milestones: {
    name: string;
    description: string;
    start_date: string;
    end_date: string;
    requirements: number[];
    dependencies: string[];
  }[];
  requirements: { id: number; description: string }[];
  milestone_resource_mapping: {
    milestone_name: string;
    resources: {
      role: string;
      skillset: string[];
      count: number;
      total_effort_days: number;
      allocated_requirements: number[];
    }[];
  }[];
  timeline_and_buffers: {
    milestone_name: string;
    planned_days: number;
    buffer_days: number;
    planned_start: string;
    planned_end: string;
  }[];
  total_project_days: number;
  total_project_buffer: number;
};

const TABS = [
  "Overview",
  "Requirements",
  "Milestones",
  "Resource Mapping",
  "Timeline & Buffer",
];

const PMO_AGENT_ID = "4ca5aec5-520f-4269-a77b-fb3376abcd3e"; // <<<<<<<< Set your PMO agent's id from MongoDB here

const PmoAgentPage: React.FC = () => {
  const { id } = useParams();
  const [tab, setTab] = useState("Overview");
  const [file, setFile] = useState<File | null>(null);
  const [startDate, setStartDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PMOResponse | null>(null);

  // Only show this page for the PMO agent id
  if (id !== PMO_AGENT_ID) {
    return (
      <div>
        <Navbar />
        <div className="py-32 flex flex-col items-center">
          <div className="text-xl font-bold text-red-600">
            This demo is only enabled for the PMO Agent.
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // ---- Upload Handler ----
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setResult(null);

    if (!file) return setError("Please upload a BRD file (PDF, DOCX, or TXT).");
    if (!startDate) return setError("Please select a project start date.");

    setLoading(true);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("start_date", startDate);

      const res = await fetch(
        "http://localhost:8000/agents/pmo/generate-pmo-plan",
        {
          method: "POST",
          body: form,
        }
      );

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Failed to generate PMO plan.");
      }

      const data: PMOResponse = await res.json();
      setResult(data);
      setTab("Overview");
    } catch (ex: any) {
      setError(ex.message);
    } finally {
      setLoading(false);
    }
  }

  // ---- Render ----
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex-1 flex flex-col items-center px-2 py-8 bg-gradient-to-br from-slate-50 via-white to-slate-100">
        <div className="w-full max-w-3xl bg-white rounded-2xl shadow-xl p-8 mb-10">
          <h1 className="text-3xl font-bold mb-2 text-primary text-center flex items-center justify-center gap-2">
            <img src="/logo.svg" className="h-10 w-10 rounded-full border shadow" alt="PMO" />
            PMO Project Planning Agent
          </h1>
          <div className="text-center text-lg text-gray-600 mb-6">
            Upload a Business Requirements Document (BRD) and select a project start date. <br />
            Get instant milestones, resources, timeline, and buffer calculation!
          </div>
          <form
            className="flex flex-col md:flex-row md:items-end gap-4 md:gap-8 justify-center mb-6"
            onSubmit={handleSubmit}
          >
            <div>
              <label className="block text-sm font-semibold mb-1">BRD File</label>
              <input
                type="file"
                accept=".pdf,.docx,.txt"
                className="block border rounded px-3 py-2"
                onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)}
              />
            </div>
            <div>
              <label className="block text-sm font-semibold mb-1">Project Start Date</label>
              <input
                type="date"
                className="block border rounded px-3 py-2"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <button
              type="submit"
              className={`rounded-xl px-8 py-3 bg-agent text-white font-bold text-lg shadow transition-all hover:bg-primary mt-6 md:mt-0 ${
                loading ? "opacity-70 pointer-events-none" : ""
              }`}
            >
              {loading ? "Processing..." : "Generate Plan"}
            </button>
          </form>
          {error && (
            <div className="mb-4 text-center text-red-600 font-semibold">{error}</div>
          )}
          {/* Tabs & Output */}
          {result && (
            <div>
              <div className="flex gap-2 mb-4 border-b">
                {TABS.map((t) => (
                  <button
                    key={t}
                    className={`px-4 py-2 font-semibold border-b-2 ${
                      tab === t
                        ? "border-primary text-primary"
                        : "border-transparent text-gray-500 hover:text-primary"
                    }`}
                    onClick={() => setTab(t)}
                  >
                    {t}
                  </button>
                ))}
              </div>
              {/* Tab Content */}
              <div>
                {tab === "Overview" && (
                  <div>
                    <h2 className="text-xl font-bold mb-2">Project Overview</h2>
                    <div className="bg-gray-50 rounded-xl p-4 text-gray-800">{result.project_overview}</div>
                    <div className="text-sm mt-3 text-gray-500">Project Start Date: <b>{result.start_date}</b></div>
                  </div>
                )}
                {tab === "Requirements" && (
                  <div>
                    <h2 className="text-xl font-bold mb-2">Extracted Requirements</h2>
                    <ol className="list-decimal ml-6 space-y-1">
                      {result.requirements.map((r) => (
                        <li key={r.id} className="bg-gray-100 rounded px-3 py-1">{r.description}</li>
                      ))}
                    </ol>
                  </div>
                )}
                {tab === "Milestones" && (
                  <div>
                    <h2 className="text-xl font-bold mb-2">Project Milestones</h2>
                    <div className="space-y-3">
                      {result.milestones.map((m, idx) => (
                        <div
                          key={m.name + idx}
                          className="bg-blue-50 border-l-4 border-blue-400 rounded p-3 shadow"
                        >
                          <div className="font-semibold text-lg">{m.name}</div>
                          <div className="text-gray-700 mb-1">{m.description}</div>
                          <div className="flex flex-wrap gap-4 text-xs text-gray-500">
                            <span>Start: <b>{m.start_date}</b></span>
                            <span>End: <b>{m.end_date}</b></span>
                            <span>Requirements: {m.requirements.join(", ")}</span>
                            {m.dependencies.length > 0 && (
                              <span>Depends on: {m.dependencies.join(", ")}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {tab === "Resource Mapping" && (
                  <div>
                    <h2 className="text-xl font-bold mb-2">Milestone Resource Mapping</h2>
                    {result.milestone_resource_mapping.map((m, idx) => (
                      <div key={m.milestone_name + idx} className="mb-6">
                        <div className="font-semibold mb-2 text-blue-800">
                          {m.milestone_name}
                        </div>
                        <table className="w-full text-sm border">
                          <thead>
                            <tr className="bg-blue-100">
                              <th className="py-1 px-2 border">Role</th>
                              <th className="py-1 px-2 border">Skillset</th>
                              <th className="py-1 px-2 border">Count</th>
                              <th className="py-1 px-2 border">Effort (days)</th>
                              <th className="py-1 px-2 border">Allocated Reqs</th>
                            </tr>
                          </thead>
                          <tbody>
                            {m.resources.map((r, i) => (
                              <tr key={r.role + i}>
                                <td className="py-1 px-2 border">{r.role}</td>
                                <td className="py-1 px-2 border">{r.skillset.join(", ")}</td>
                                <td className="py-1 px-2 border text-center">{r.count}</td>
                                <td className="py-1 px-2 border text-center">{r.total_effort_days}</td>
                                <td className="py-1 px-2 border text-center">{r.allocated_requirements.join(", ")}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ))}
                  </div>
                )}
                {tab === "Timeline & Buffer" && (
                  <div>
                    <h2 className="text-xl font-bold mb-2">Timeline & Buffer</h2>
                    <table className="w-full text-sm border mb-4">
                      <thead>
                        <tr className="bg-blue-100">
                          <th className="py-1 px-2 border">Milestone</th>
                          <th className="py-1 px-2 border">Planned Days</th>
                          <th className="py-1 px-2 border">Buffer Days</th>
                          <th className="py-1 px-2 border">Planned Start</th>
                          <th className="py-1 px-2 border">Planned End</th>
                        </tr>
                      </thead>
                      <tbody>
                        {result.timeline_and_buffers.map((tb, i) => (
                          <tr key={tb.milestone_name + i}>
                            <td className="py-1 px-2 border">{tb.milestone_name}</td>
                            <td className="py-1 px-2 border text-center">{tb.planned_days}</td>
                            <td className="py-1 px-2 border text-center">{tb.buffer_days}</td>
                            <td className="py-1 px-2 border">{tb.planned_start}</td>
                            <td className="py-1 px-2 border">{tb.planned_end}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <div className="font-semibold mt-2">
                      Total Project Days: <span className="text-primary">{result.total_project_days}</span>
                      &nbsp;&nbsp;|&nbsp;&nbsp;
                      Total Project Buffer: <span className="text-primary">{result.total_project_buffer}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          {/* Loader Overlay */}
          {loading && (
            <div className="fixed inset-0 bg-white/60 flex items-center justify-center z-50 rounded-2xl">
              <svg className="animate-spin h-12 w-12 text-primary" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C6.477 0 2 4.477 2 10h2zm2 5.291A7.962 7.962 0 014 12H2c0 2.137.84 4.084 2.229 5.584l1.771-1.293z"/>
              </svg>
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default PmoAgentPage;
