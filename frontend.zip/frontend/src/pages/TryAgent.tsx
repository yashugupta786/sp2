import React from "react";
import { useParams, Link } from "react-router-dom";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import PmoAgentPage from "./PmoAgentPage";

const PMO_AGENT_ID = "4ca5aec5-520f-4269-a77b-fb3376abcd3e";

const TryAgent = () => {
  const { id } = useParams();

  // If the agent ID matches PMO Agent, load special UI
  if (id === PMO_AGENT_ID) {
    return <PmoAgentPage />;
  }

  // Otherwise, default placeholder for other agents
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex flex-1 flex-col items-center justify-center px-4 py-10">
        <div className="bg-white rounded-xl shadow-xl p-8 max-w-xl w-full">
          <h1 className="text-2xl font-bold mb-4 text-center text-primary">
            Try this Agent
          </h1>
          <div className="text-center text-gray-700 mb-4">
            <span>This is a placeholder to try agent <b>{id}</b>.</span>
          </div>
          <Link to="/my-agents" className="py-2 px-6 rounded bg-primary text-white font-semibold hover:bg-agent transition mt-4">
            ← Back to My Agents
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default TryAgent;
