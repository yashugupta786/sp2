import React, { useEffect, useState } from "react";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";
import { getAgents, retireAgent } from "../api/myAgentApi";
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Legend,
} from "recharts";

// --- MOCK DATA for other tabs ---
const REQUESTED_AGENTS = [
  { id: 1, query: "Meeting minutes summarizer", requestedBy: "raj@acme.com", date: "2024-06-20", status: "open" },
  { id: 2, query: "Invoice parser", requestedBy: "priya@acme.com", date: "2024-06-21", status: "open" },
  { id: 3, query: "Patent search AI", requestedBy: "user3@acme.com", date: "2024-06-15", status: "in progress" },
];
const FEEDBACKS = [
  { id: 1, text: "ResearchGen is slow to respond", user: "user2@acme.com", date: "2024-06-25" },
  { id: 2, text: "Need support for legal contracts in LegalQ", user: "user4@acme.com", date: "2024-06-23" },
];
const API_USAGE = [
  { agent: "FinanceDoc AI", calls: 4021, errors: 11 },
  { agent: "HR Buddy", calls: 3020, errors: 4 },
  { agent: "LegalQ", calls: 1072, errors: 1 },
  { agent: "ResearchGen", calls: 4999, errors: 9 },
];

// --- Analytics helpers ---
const STATUS_COLORS = { active: "#22c55e", retired: "#f87171" };
const CATEGORY_COLORS = ["#6366f1", "#f59e42", "#34d399", "#f43f5e", "#0ea5e9", "#a855f7", "#fbbf24"];

function getStats(agents: any[]) {
  const total = agents.length;
  const active = agents.filter(a => a.status !== "retired").length;
  const retired = total - active;
  const subscribers = agents.reduce((sum, a) => sum + (a.subscribers || 0), 0);
  const totalApiCalls = agents.reduce((sum, a) => sum + (a.apiCalls || Math.floor(Math.random() * 5000)), 0);
  return { total, active, retired, subscribers, totalApiCalls };
}

const AdminDashboard = () => {
  const [tab, setTab] = useState("overview");
  const [agents, setAgents] = useState<any[]>([]);
  const [announcement, setAnnouncement] = useState("");
  const [announcements, setAnnouncements] = useState<{ msg: string, date: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);

  const fetchAgents = () => {
    setLoading(true);
    getAgents().then((data) => {
      const withStatus = data.map(a => ({ ...a, status: a.status || "active" }));
      setAgents(withStatus);
      setLoading(false);
    });
  };

  useEffect(() => {
    fetchAgents();
    // eslint-disable-next-line
  }, []);

  // Handler for retire/unretire (toggle)
const toggleRetire = async (id: string) => {
  const agent = agents.find(a => a.id === id);
  if (!agent) return;
  const action = agent.status === "retired" ? "unretire" : "retire";
  const token = localStorage.getItem("token"); // Or however you store your admin token

  if (!token) {
    setToast("No admin token found. Please login.");
    return;
  }

  try {
    await retireAgent(id, action, token); // <-- pass action AND token!
    setToast(`Agent ${action === "retire" ? "retired" : "unretired"} successfully.`);
    fetchAgents();
  } catch (err) {
    setToast("Failed to update agent status");
  }
  setTimeout(() => setToast(null), 1600);
};


  // --- Analytics Prep ---
  const stats = getStats(agents);
  const pieStatusData = [
    { name: "Active", value: stats.active },
    { name: "Retired", value: stats.retired },
  ];
  const categories = Array.from(new Set(agents.map(a => a.category)));
  const pieCategoryData = categories.map((cat, i) => ({
    name: cat, value: agents.filter(a => a.category === cat).length,
    color: CATEGORY_COLORS[i % CATEGORY_COLORS.length]
  }));
  const barData = agents.map(a => ({
    name: a.name,
    Subscribers: a.subscribers,
    "API Calls": a.apiCalls || Math.floor(Math.random() * 5000),
  }));

  // Announcement handler
  const sendAnnouncement = () => {
    if (!announcement.trim()) return;
    setAnnouncements([{ msg: announcement, date: new Date().toLocaleString() }, ...announcements]);
    setAnnouncement("");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex-1 flex flex-col items-center px-4 py-10">
        <div className="w-full max-w-6xl bg-white rounded-xl shadow-xl p-8">
          <h1 className="text-3xl font-bold mb-6 text-primary text-center">Admin Dashboard</h1>

          {/* Tabs */}
          <div className="flex gap-2 mb-8 border-b">
            {[
              { key: "overview", label: "Overview" },
              { key: "agents", label: "All Agents" },
              { key: "requests", label: "Requested Agents" },
              { key: "api", label: "API Usage" },
              { key: "feedback", label: "Feedback/Reports" },
              { key: "announce", label: "Announcements" },
            ].map(t => (
              <button
                key={t.key}
                className={`px-5 py-2 -mb-px font-semibold border-b-2 ${tab === t.key ? "border-primary text-primary" : "border-transparent text-gray-500 hover:text-primary"}`}
                onClick={() => setTab(t.key)}
              >{t.label}</button>
            ))}
          </div>

          {/* --- Overview Tab --- */}
          {tab === "overview" && (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                <div className="bg-blue-50 p-5 rounded-xl text-center">
                  <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
                  <div className="text-gray-600 text-sm font-medium">Total Agents</div>
                </div>
                <div className="bg-green-50 p-5 rounded-xl text-center">
                  <div className="text-2xl font-bold text-green-600">{stats.active}</div>
                  <div className="text-gray-600 text-sm font-medium">Active Agents</div>
                </div>
                <div className="bg-red-50 p-5 rounded-xl text-center">
                  <div className="text-2xl font-bold text-red-500">{stats.retired}</div>
                  <div className="text-gray-600 text-sm font-medium">Retired Agents</div>
                </div>
                <div className="bg-yellow-50 p-5 rounded-xl text-center">
                  <div className="text-2xl font-bold text-yellow-500">{stats.subscribers}</div>
                  <div className="text-gray-600 text-sm font-medium">Total Subscribers</div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                {/* Status Pie */}
                <div className="bg-gray-50 rounded-xl p-4 flex flex-col items-center">
                  <h3 className="text-base font-semibold mb-2">Agent Status</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={pieStatusData} dataKey="value" cx="50%" cy="50%" outerRadius={60} label>
                        {pieStatusData.map((entry, i) => (
                          <Cell key={i} fill={i === 0 ? STATUS_COLORS.active : STATUS_COLORS.retired} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                {/* Category Pie */}
                <div className="bg-gray-50 rounded-xl p-4 flex flex-col items-center">
                  <h3 className="text-base font-semibold mb-2">Agent by Category</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie data={pieCategoryData} dataKey="value" cx="50%" cy="50%" outerRadius={60} label>
                        {pieCategoryData.map((entry, i) => (
                          <Cell key={i} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                {/* Bar: Subscribers/API calls */}
                <div className="bg-gray-50 rounded-xl p-4 flex flex-col items-center">
                  <h3 className="text-base font-semibold mb-2">Subscribers & API Calls</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={barData}>
                      <XAxis dataKey="name" hide />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="Subscribers" fill="#6366f1" />
                      <Bar dataKey="API Calls" fill="#fbbf24" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </>
          )}

          {/* --- Agents Tab --- */}
          {tab === "agents" && (
            <>
              <h2 className="text-xl font-semibold mb-3">All Agents</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border text-sm">
                  <thead>
                    <tr className="bg-blue-50">
                      <th className="py-2 px-4 border">Name</th>
                      <th className="py-2 px-4 border">Category</th>
                      <th className="py-2 px-4 border">Publisher</th>
                      <th className="py-2 px-4 border">Status</th>
                      <th className="py-2 px-4 border">Subscribers</th>
                      <th className="py-2 px-4 border">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {agents.map(agent => (
                      <tr key={agent.id} className={agent.status === "retired" ? "bg-gray-100" : ""}>
                        <td className="py-2 px-4 border font-semibold flex items-center gap-2">
                          <img src={agent.logo} alt="" className="h-6 w-6 rounded-full" />
                          {agent.name}
                        </td>
                        <td className="py-2 px-4 border">{agent.category}</td>
                        <td className="py-2 px-4 border">{agent.publisher || "-"}</td>
                        <td className="py-2 px-4 border">
                          <span
                            className={
                              agent.status === "retired"
                                ? "bg-red-100 text-red-700 px-2 py-0.5 rounded"
                                : "bg-green-100 text-green-700 px-2 py-0.5 rounded"
                            }
                          >
                            {agent.status === "retired" ? "Retired" : "Active"}
                          </span>
                        </td>
                        <td className="py-2 px-4 border text-center">{agent.subscribers}</td>
                        <td className="py-2 px-4 border text-center flex gap-2">
                          <button
                            className={
                              agent.status === "retired"
                                ? "px-3 py-1 bg-green-500 text-white rounded hover:bg-green-700"
                                : "px-3 py-1 bg-red-500 text-white rounded hover:bg-red-700"
                            }
                            onClick={() => toggleRetire(agent.id)}
                          >
                            {agent.status === "retired" ? "Unretire" : "Retire"}
                          </button>
                          {/* TODO: Add Edit/Delete/View buttons */}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {toast && (
                  <div className="fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-2 bg-primary text-white rounded shadow font-semibold transition-all z-40">
                    {toast}
                  </div>
                )}
              </div>
            </>
          )}

          {/* --- Requested Agents Tab --- */}
          {tab === "requests" && (
            <>
              <h2 className="text-xl font-semibold mb-3">Requested Agents</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border text-sm">
                  <thead>
                    <tr className="bg-blue-50">
                      <th className="py-2 px-4 border">Requested Query</th>
                      <th className="py-2 px-4 border">Requested By</th>
                      <th className="py-2 px-4 border">Date</th>
                      <th className="py-2 px-4 border">Status</th>
                      <th className="py-2 px-4 border">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {REQUESTED_AGENTS.map(req => (
                      <tr key={req.id}>
                        <td className="py-2 px-4 border">{req.query}</td>
                        <td className="py-2 px-4 border">{req.requestedBy}</td>
                        <td className="py-2 px-4 border">{req.date}</td>
                        <td className="py-2 px-4 border">{req.status}</td>
                        <td className="py-2 px-4 border">
                          <button className="px-3 py-1 bg-primary text-white rounded hover:bg-agent mr-2">
                            Mark In Progress
                          </button>
                          <button className="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-700">
                            Assign to Dev
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {/* --- API Usage Tab --- */}
          {tab === "api" && (
            <>
              <h2 className="text-xl font-semibold mb-3">API Usage Analytics</h2>
              <div className="overflow-x-auto mb-6">
                <table className="min-w-full bg-white border text-sm">
                  <thead>
                    <tr className="bg-blue-50">
                      <th className="py-2 px-4 border">Agent</th>
                      <th className="py-2 px-4 border">API Calls</th>
                      <th className="py-2 px-4 border">Errors</th>
                    </tr>
                  </thead>
                  <tbody>
                    {API_USAGE.map(row => (
                      <tr key={row.agent}>
                        <td className="py-2 px-4 border">{row.agent}</td>
                        <td className="py-2 px-4 border">{row.calls}</td>
                        <td className="py-2 px-4 border text-red-500">{row.errors}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {/* --- Feedback Tab --- */}
          {tab === "feedback" && (
            <>
              <h2 className="text-xl font-semibold mb-3">User & Developer Feedback</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border text-sm">
                  <thead>
                    <tr className="bg-blue-50">
                      <th className="py-2 px-4 border">Feedback</th>
                      <th className="py-2 px-4 border">User</th>
                      <th className="py-2 px-4 border">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {FEEDBACKS.map(fb => (
                      <tr key={fb.id}>
                        <td className="py-2 px-4 border">{fb.text}</td>
                        <td className="py-2 px-4 border">{fb.user}</td>
                        <td className="py-2 px-4 border">{fb.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {/* --- Announcements Tab --- */}
          {tab === "announce" && (
            <>
              <h2 className="text-xl font-semibold mb-3">Send Announcement</h2>
              <div className="flex flex-col gap-2 max-w-lg">
                <textarea
                  className="border rounded px-4 py-2 mb-2"
                  value={announcement}
                  onChange={e => setAnnouncement(e.target.value)}
                  placeholder="Enter your announcement to all users/developers..."
                  rows={3}
                />
                <button
                  className="px-6 py-2 rounded bg-primary text-white font-semibold hover:bg-agent transition w-max"
                  onClick={sendAnnouncement}
                >Send Announcement</button>
              </div>
              <h3 className="mt-8 mb-2 font-semibold text-lg">Previous Announcements</h3>
              <ul className="text-sm">
                {announcements.length === 0 && (
                  <li className="text-gray-400">No announcements yet.</li>
                )}
                {announcements.map((a, i) => (
                  <li key={i} className="mb-2">
                    <span className="font-medium text-primary">{a.msg}</span>
                    <span className="ml-3 text-gray-400 text-xs">{a.date}</span>
                  </li>
                ))}
              </ul>
            </>
          )}

        </div>
      </div>
      <Footer />
    </div>
  );
};

export default AdminDashboard;
