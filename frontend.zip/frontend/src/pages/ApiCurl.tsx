import React from "react";
import { useParams, Link } from "react-router-dom";
import Navbar from "../components/Common/Navbar";
import Footer from "../components/Common/Footer";

const ApiCurl = () => {
  const { id } = useParams();

  // For now, just show agent ID; you can make it dynamic later!
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <div className="flex flex-1 flex-col items-center justify-center px-4 py-10">
        <div className="bg-white rounded-xl shadow-xl p-8 max-w-xl w-full">
          <h1 className="text-2xl font-bold mb-4 text-primary">
            API & cURL Access for <span className="text-agent">{id}</span>
          </h1>
          <div className="mb-4">
            <div className="font-semibold mb-2">Your API Token</div>
            <button className="bg-agent text-white font-semibold rounded px-6 py-2 hover:bg-primary transition mb-2">
              Generate API Token
            </button>
          </div>
          <div className="mb-4">
            <div className="font-semibold mb-2">Example cURL Request</div>
            <pre className="bg-gray-100 text-sm rounded p-3 overflow-x-auto">
{`curl -X POST \\
  'https://api.agentpath.com/agents/${id}/summarize' \\
  -H 'Authorization: Bearer <YOUR_TOKEN_HERE>' \\
  -H 'Content-Type: application/json' \\
  -d '{"input": "Your query or data"}'
`}
            </pre>
          </div>
          <div>
            <div className="font-semibold mb-2">How to Use</div>
            <ol className="list-decimal list-inside text-gray-600 text-sm space-y-1">
              <li>Generate your API token above.</li>
              <li>Send POST requests to the API endpoint shown above.</li>
              <li>Include your token in the <b>Authorization</b> header.</li>
              <li>Input/output details depend on the agent’s capability.</li>
            </ol>
          </div>
         <Link to="/my-agents" className="py-2 px-6 rounded bg-primary text-white font-semibold hover:bg-agent transition mt-4">
  ← Back to My Agents
</Link>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ApiCurl;
