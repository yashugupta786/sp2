import React from "react";
import { useParams, Link } from "react-router-dom";
import { getAgents } from "../api/myAgentApi";
import type { Agent } from "../api/myAgentApi";
import AgentKPIs from "../components/Agent/AgentKPIs";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from "recharts";
import { StarIcon, ArrowLeftIcon } from "@heroicons/react/24/solid";

// Mock monthly trend
const mockPerformance = [
  { name: "Jan", performance: 97 },
  { name: "Feb", performance: 98 },
  { name: "Mar", performance: 96 },
  { name: "Apr", performance: 99 },
  { name: "May", performance: 98 }
];

// Mock star breakdown for rating
const mockStarBreakdown = [
  { stars: 5, count: 12 },
  { stars: 4, count: 3 },
  { stars: 3, count: 1 },
  { stars: 2, count: 0 },
  { stars: 1, count: 0 }
];

// Pie colors
const donutColors = ["#34d399", "#f87171"];

const AgentDetail = () => {
  const { id } = useParams();
  const [agent, setAgent] = React.useState<Agent | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    getAgents().then(data => {
      const found = data.find(a => a.id === id);
      setAgent(found ?? null);
      setLoading(false);
    });
  }, [id]);

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }
  if (!agent) {
    return <div className="flex flex-col items-center mt-32 text-lg">
      <div>Agent not found.</div>
      <Link to="/agents" className="text-primary mt-2 flex items-center gap-1 hover:underline">
        <ArrowLeftIcon className="w-4 h-4" /> Back to Agents
      </Link>
    </div>;
  }

  // For the donut chart: errors vs success
  const errorData = [
    { name: "Success", value: 100 - agent.errorRate },
    { name: "Errors", value: agent.errorRate }
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col items-center pt-10 pb-20 px-4">
      <div className="w-full max-w-3xl bg-white rounded-xl shadow-xl p-8 relative animate-fade-in">
        <Link to="/agents" className="absolute top-5 left-5 flex items-center text-primary font-semibold hover:underline">
          <ArrowLeftIcon className="h-5 w-5 mr-1" /> Agents
        </Link>
        <div className="flex items-center gap-6 mb-5">
          <img src={agent.logo} alt={agent.name} className="h-20 w-20 rounded-full border shadow" />
          <div>
            <h1 className="text-3xl font-extrabold mb-1">{agent.name}</h1>
            <div className="text-xs bg-blue-100 text-blue-700 rounded px-2 py-0.5 inline-block">{agent.category}</div>
          </div>
        </div>
        <div className="text-lg mb-6 text-gray-700">{agent.description}</div>
        <AgentKPIs agent={agent} showAll />

        {/* Analytics Section */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Performance Trend Bar Chart */}
          <div>
            <div className="text-base font-semibold mb-2">Performance Trend (last 5 months)</div>
            <div className="w-full h-44 bg-gray-50 rounded-xl flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mockPerformance}>
                  <XAxis dataKey="name" />
                  <YAxis domain={[90, 100]} />
                  <Tooltip />
                  <Bar dataKey="performance" fill="#2563eb" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
          {/* Error Rate Donut Chart */}
          <div>
            <div className="text-base font-semibold mb-2">Error Rate</div>
            <div className="w-full h-44 bg-gray-50 rounded-xl flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={errorData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={65}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {errorData.map((entry, i) => (
                      <Cell key={i} fill={donutColors[i]} />
                    ))}
                  </Pie>
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Ratings Breakdown */}
        <div className="mt-10">
          <div className="text-base font-semibold mb-2">Ratings Breakdown</div>
          <div className="flex gap-3 items-end">
            {mockStarBreakdown.map((item) => (
              <div key={item.stars} className="flex flex-col items-center">
                <div className="text-xs text-gray-500 mb-1">{item.stars} Star</div>
                <div className="flex items-center gap-1">
                  <StarIcon className="h-5 w-5 text-yellow-400" />
                  <span className="font-bold">{item.count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Reviews */}
        <div className="mt-10">
          <div className="text-base font-semibold mb-2">User Reviews</div>
          {agent.reviews.length === 0 ? (
            <div className="text-gray-400">No reviews yet.</div>
          ) : (
            <div className="flex flex-col gap-4">
              {agent.reviews.map((review, i) => (
                <div key={i} className="rounded-lg bg-slate-50 p-3 flex flex-col">
                  <div className="flex gap-2 items-center mb-1">
                    <StarIcon className="h-4 w-4 text-yellow-400" />
                    <span className="font-bold text-gray-700">{review.user}</span>
                    <span className="text-gray-400">({review.rating}/5)</span>
                  </div>
                  <div className="text-gray-600 text-sm">{review.text}</div>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="mt-8 flex gap-3">
          <button
            className="py-2 px-6 rounded bg-primary text-white font-semibold hover:bg-agent transition shadow"
            // TODO: Connect to subscribe API
            onClick={() => alert("Subscribed! (Hook this to real API)")}
          >
            Subscribe
          </button>
          <button
            className="py-2 px-6 rounded bg-slate-100 text-primary font-semibold border hover:bg-slate-200 transition shadow"
            // TODO: Connect to unsubscribe API
            onClick={() => alert("Unsubscribed! (Hook this to real API)")}
          >
            Unsubscribe
          </button>
        </div>
      </div>
    </div>
  );
};

export default AgentDetail;
