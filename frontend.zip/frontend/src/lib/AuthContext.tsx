import React, { createContext, useContext, useEffect, useState } from "react";

export type AuthUser = {
  id: string;
  email: string;
  name: string;
  is_admin: boolean;
} | null;

type AuthContextType = {
  user: AuthUser;
  token: string | null;
  loading: boolean;                      // <--- Added
  login: (token: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  loading: true,                         // <--- Added
  login: async () => {},
  logout: () => {},
  refreshUser: async () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("token"));
  const [user, setUser] = useState<AuthUser>(null);
  const [loading, setLoading] = useState(true);      // <--- Added

  useEffect(() => {
    if (token) {
      refreshUser().finally(() => setLoading(false)); // <--- Always stop loading
    } else {
      setUser(null);
      setLoading(false);                              // <--- Always stop loading
    }
    // eslint-disable-next-line
  }, [token]);

  const login = async (newToken: string) => {
    localStorage.setItem("token", newToken);
    setToken(newToken);
    setLoading(true);                                 // <--- Added (for UX)
    await refreshUser();
    setLoading(false);                                // <--- Added
  };

  const logout = () => {
    localStorage.removeItem("token");
    setToken(null);
    setUser(null);
    setLoading(false);                                // <--- Added
  };

  const refreshUser = async () => {
    if (!token) {
      setUser(null);
      setLoading(false);                              // <--- Added
      return;
    }
    try {
      const res = await fetch("http://localhost:8000/auth/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setUser(data);
    } catch {
      setUser(null);
      setToken(null);
      localStorage.removeItem("token");
    }
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, logout, refreshUser }}>
      {loading ? <div>Loading...</div> : children}
    </AuthContext.Provider>
  );
};
