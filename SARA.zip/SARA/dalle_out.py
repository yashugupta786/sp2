import requests
import json
from final_dalle_prompt import dalle_final_prompt
url = "https://open-group.openai.azure.com/openai/deployments/dall-e-3/images/generations?api-version=2024-02-01"

payload = json.dumps({
  "model": "dall-e-3",
  "prompt": "create architecture diagram for aws for RAG pipeline for a company ",
  "size": "1024x1024",
  "style": "vivid",
  "quality": "standard",
  "n": 1
})
headers = {
  'Content-Type': 'application/json',
  'Authorization': 'Bearer 6YHSyQC3kPpUjw4nCS3dNSujpX6gikZPRc17t0RfJeSSQUUehkhjJQQJ99BFACYeBjFXJ3w3AAABACOGxmk6'
}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)
