dalle_final_prompt='''Create a professional, clean AWS cloud architecture diagram on a white background, using standard AWS and cloud provider icons, clear labeled boxes, and arrows. The diagram is horizontally organized:

- On the far left, show a "users" icon labeled "users".
- Draw an arrow from "users" to a "WAF" security icon, then an arrow to an "Imperva Firewall" security icon, then an arrow to an "Application Load Balancer" (ALB) box labeled "Application Load Balancer" with a note "Rules Based Routing".
- Enclose the main architecture in a large box labeled "Virtual Private Cloud (VPC)", containing a nested box for "Availability Zones A,B,C".
- Inside, show two main subnet boxes: "Public subnet" (left) and "Private subnet" (right).
- In the "Public subnet", include a box labeled "Security group (public)" containing the ALB.
- In the "Private subnet", include a box labeled "Security group (private)" containing:
    - "Amazon ECS Service" box, connected by arrow to "Amazon ECS environment" box (with notes: "2 Stage Docker Build", "GATE Studio Multiple containers", "Frontend REACT/VITE", "Python Build", "API Integration").
    - "Amazon ECS environment" connects by arrows to:
        - "Amazon Auto Scaling Group" icon,
        - "Amazon RDS Postgres (Multi AZ)" database icon,
        - "Custom Components" icon,
        - A vertical panel on the far right labeled "Models / Services" listing: Azure OpenAI, AWS Bedrock, NVIDIA Services, Anthropic, Cohere, Langchain, Google, Hugging Face.
    - "Amazon ECS Service", "Amazon ECS environment", "Amazon Auto Scaling Group", and "Custom Components" all connect by arrows to an "Amazon S3 (Backups)" icon at the bottom of the private subnet, labeled "Backups for all compute resources".
    - "Amazon ECS Service" also connects to an "Amazon ECR" icon.
- Place a "Secret Manager" icon at the top of the VPC.
- At the bottom, add three labeled side boxes: "Data Scientist" (left), "Developer" (center), "Business Analyst" (right).
- Use color-coded boxes for subnets, security groups, and service types. Use clear arrows to indicate all data flows and integrations.
- Include a legend explaining the color codes, icons, and that the rightmost panel lists external AI/ML model providers.
- Ensure all security groups are explicitly labeled as "Security group (public)" and "Security group (private)".
- The style should be clean, readable, and suitable for technical documentation.
The output image is a architecture diagram for the companies
'''



