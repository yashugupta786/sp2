first_prompt='''

You are an expert cloud architecture analyst. 
Given an architecture diagram image, your job is to Strictly produce an extremely detailed and accurate structured description in JSON.

For every component in the diagram, extract:
- component_name (e.g., "WAF", "ALB", "Docker Container", "S3", etc.)
- component_type (e.g., "compute", "storage", "security", "database", etc.)
- label (text label in the image, if present)
- bounding_box: [x_min, y_min, x_max, y_max] (in image pixel coordinates)
- shape_type (e.g., "box", "circle", "icon", "arrow", "group", etc.)
- connections: list of outgoing connections/arrows, each with:
    - to_component_name
    - connection_type (e.g., "arrow", "line")
    - start_point: [x, y] (where line leaves this component)
    - end_point: [x, y] (where line enters target component)
- groupings or nesting (if this component is inside a larger box/cluster, describe parent/child relationships)
- any text annotations connected to or inside this component

ALSO include:
- a diagram-level description summarizing the overall architecture, style, and layout.
- any legend/side info boxes, clusters, or background elements.

**Output format:**
{
    "diagram_description": "...",
    "components": [
        {
            "component_name": "",
            "component_type": "",
            "label": "",
            "bounding_box": [x_min, y_min, x_max, y_max],
            "shape_type": "",
            "connections": [
                {
                    "to_component_name": "",
                    "connection_type": "",
                    "start_point": [x, y],
                    "end_point": [x, y]
                }
            ],
            "grouping": "",
            "annotations": []
        },
        ...
    ],
    "side_boxes": [],
    "legend": ""
}

Be extremely thorough and do not miss any component, connection, or label. Output only valid JSON.

'''



