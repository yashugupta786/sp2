from PIL import Image, ImageEnhance
from prompt2 import update_prompt
import openai
import json
import base64
from mimetypes import guess_type
from openai import AzureOpenAI
api_base = "https://open-group.openai.azure.com/"
api_key= "6YHSyQC3kPpUjw4nCS3dNSujpX6gikZPRc17t0RfJeSSQUUehkhjJQQJ99BFACYeBjFXJ3w3AAABACOGxmk6"
deployment_name = 'gpt-4.1'
api_version = '2023-05-15' # this might change in the future

from openai import AzureOpenAI
client = AzureOpenAI(
    azure_endpoint=api_base,
    api_key=api_key,
    api_version=api_version,

)

completion = client.chat.completions.create(
    model=deployment_name,
messages = [
    {"role": "system", "content": "You are a cloud architecture compliance assistant."},
    {"role": "user", "content": update_prompt}
],max_tokens=4096,
    temperature=0
)

l=completion.json()
p=json.loads(l)
final_out=p["choices"][0]["message"]["content"]
print(final_out)