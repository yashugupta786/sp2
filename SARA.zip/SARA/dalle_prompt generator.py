from PIL import Image, ImageEnhance
from prompt3 import dalle_prompt,dalle_sys_prompt
import openai
import json
import base64
from mimetypes import guess_type
from openai import AzureOpenAI
api_base = "https://open-group.openai.azure.com/"
api_key= "6YHSyQC3kPpUjw4nCS3dNSujpX6gikZPRc17t0RfJeSSQUUehkhjJQQJ99BFACYeBjFXJ3w3AAABACOGxmk6"
deployment_name = 'gpt-4.1'
api_version = '2023-05-15' # this might change in the future

from openai import AzureOpenAI
client = AzureOpenAI(
    azure_endpoint=api_base,
    api_key=api_key,
    api_version=api_version,

)

completion = client.chat.completions.create(
    model=deployment_name,
messages = [
    {"role": "system", "content": dalle_sys_prompt},
    {"role": "user", "content": dalle_prompt}
],max_tokens=2048,
    temperature=0
)

l=completion.json()
p=json.loads(l)
final_out=p["choices"][0]["message"]["content"]
print(final_out)