dalle_prompt='''
Here is a structured JSON description of a cloud architecture diagram, fully compliant with our guidelines:

Below is the compliance review and the updated JSON:



**Compliance Review:**

1. **WAF and Imperva Firewall:**  
   - WAF is present and connected.  
   - Imperva firewall is missing.  
   - **Action:** Add Imperva firewall between WAF and ALB, connect WAF → Imperva → ALB.

2. **Compute resources must connect to S3 for backups:**  
   - Compute resources: Amazon ECS Service, Amazon ECS environment, Custom Components, Amazon Auto Scaling Group.  
   - No S3 bucket present or connected.  
   - **Action:** Add S3 bucket in private subnet, connect all compute resources to S3.

3. **Use RDS for all persistent database needs:**  
   - RDS is present and used.  
   - **Compliant.**

4. **All security groups must be explicitly labeled:**  
   - Security groups are present but labeled generically as "Security group".  
   - **Action:** Update labels to "Security group (public)" and "Security group (private)" for clarity.

---

**Below is the FULL, updated, compliant JSON.**  
**All additions and changes for compliance are marked with `"compliance_added": true` or `"compliance_modified": true` in the relevant entries.**

```json
{
    "diagram_description": "This architecture diagram illustrates a cloud-native application deployed on AWS, leveraging ECS for container orchestration, RDS for database, and integrating with multiple external AI/ML model providers. The layout is horizontally organized, with users entering from the left, traversing through a WAF, Imperva firewall, ALB, and into a VPC with public and private subnets. The private subnet hosts the main ECS environment, which includes multiple containers, frontend/backend components, and connects to supporting AWS services (ECR, Auto Scaling, RDS, S3, custom components). On the far right, a vertical panel lists external AI/ML model providers (Azure OpenAI, AWS Bedrock, NVIDIA, Anthropic, Cohere, Langchain, Google, Hugging Face) under 'Models/Services'. The diagram uses color-coded boxes for subnets, security groups, and service types, with clear arrows indicating data flow and integration points. There are also user role annotations at the bottom and a focus on rapid prototyping.",
    "components": [
        {
            "component_name": "users",
            "component_type": "user",
            "label": "users",
            "bounding_box": [10, 220, 60, 270],
            "shape_type": "icon",
            "connections": [
                {
                    "to_component_name": "WAF",
                    "connection_type": "arrow",
                    "start_point": [60, 245],
                    "end_point": [90, 245]
                }
            ],
            "grouping": "",
            "annotations": []
        },
        {
            "component_name": "WAF",
            "component_type": "security",
            "label": "WAF",
            "bounding_box": [90, 235, 130, 265],
            "shape_type": "icon",
            "connections": [
                {
                    "to_component_name": "Imperva Firewall",
                    "connection_type": "arrow",
                    "start_point": [130, 245],
                    "end_point": [150, 245],
                    "compliance_added": true
                }
            ],
            "grouping": "",
            "annotations": []
        },
        {
            "component_name": "Imperva Firewall",
            "component_type": "security",
            "label": "Imperva Firewall",
            "bounding_box": [150, 235, 170, 265],
            "shape_type": "icon",
            "connections": [
                {
                    "to_component_name": "Application Load Balancer",
                    "connection_type": "arrow",
                    "start_point": [170, 245],
                    "end_point": [170, 245],
                    "compliance_added": true
                }
            ],
            "grouping": "",
            "annotations": [],
            "compliance_added": true
        },
        {
            "component_name": "Virtual Private Cloud (VPC)",
            "component_type": "network",
            "label": "Virtual Private Cloud (VPC)",
            "bounding_box": [70, 40, 1020, 540],
            "shape_type": "box",
            "connections": [],
            "grouping": "",
            "annotations": ["Secret Manager"]
        },
        {
            "component_name": "Secret Manager",
            "component_type": "security",
            "label": "Secret Manager",
            "bounding_box": [250, 40, 400, 70],
            "shape_type": "icon",
            "connections": [],
            "grouping": "Virtual Private Cloud (VPC)",
            "annotations": []
        },
        {
            "component_name": "Availability Zones A,B,C",
            "component_type": "network",
            "label": "Availability Zones A,B,C",
            "bounding_box": [90, 60, 1000, 520],
            "shape_type": "box",
            "connections": [],
            "grouping": "Virtual Private Cloud (VPC)",
            "annotations": []
        },
        {
            "component_name": "Public subnet",
            "component_type": "network",
            "label": "Public subnet",
            "bounding_box": [110, 100, 350, 480],
            "shape_type": "box",
            "connections": [],
            "grouping": "Availability Zones A,B,C",
            "annotations": []
        },
        {
            "component_name": "Security group (public)",
            "component_type": "security",
            "label": "Security group (public)",
            "bounding_box": [130, 130, 330, 460],
            "shape_type": "box",
            "connections": [],
            "grouping": "Public subnet",
            "annotations": [],
            "compliance_modified": true
        },
        {
            "component_name": "Application Load Balancer",
            "component_type": "network",
            "label": "Application Load Balancer",
            "bounding_box": [170, 210, 270, 280],
            "shape_type": "box",
            "connections": [
                {
                    "to_component_name": "Amazon ECS Service",
                    "connection_type": "arrow",
                    "start_point": [270, 245],
                    "end_point": [370, 245]
                }
            ],
            "grouping": "Security group (public)",
            "annotations": ["Rules Based Routing"]
        },
        {
            "component_name": "Private subnet",
            "component_type": "network",
            "label": "Private subnet",
            "bounding_box": [370, 100, 980, 480],
            "shape_type": "box",
            "connections": [],
            "grouping": "Availability Zones A,B,C",
            "annotations": []
        },
        {
            "component_name": "Security group (private)",
            "component_type": "security",
            "label": "Security group (private)",
            "bounding_box": [390, 130, 960, 460],
            "shape_type": "box",
            "connections": [],
            "grouping": "Private subnet",
            "annotations": [],
            "compliance_modified": true
        },
        {
            "component_name": "Amazon ECS Service",
            "component_type": "compute",
            "label": "Amazon ECS Service",
            "bounding_box": [370, 210, 470, 280],
            "shape_type": "box",
            "connections": [
                {
                    "to_component_name": "Amazon ECS environment",
                    "connection_type": "arrow",
                    "start_point": [470, 245],
                    "end_point": [540, 245]
                },
                {
                    "to_component_name": "Amazon ECR",
                    "connection_type": "arrow",
                    "start_point": [420, 280],
                    "end_point": [500, 350]
                },
                {
                    "to_component_name": "Amazon S3 (Backups)",
                    "connection_type": "arrow",
                    "start_point": [420, 280],
                    "end_point": [600, 470],
                    "compliance_added": true
                }
            ],
            "grouping": "Security group (private)",
            "annotations": ["AWS Private link"]
        },
        {
            "component_name": "Amazon ECS environment",
            "component_type": "compute",
            "label": "Amazon ECS environment",
            "bounding_box": [540, 150, 900, 350],
            "shape_type": "box",
            "connections": [
                {
                    "to_component_name": "Amazon Auto Scaling Group",
                    "connection_type": "arrow",
                    "start_point": [700, 350],
                    "end_point": [700, 400]
                },
                {
                    "to_component_name": "Amazon RDS Postgres (Multi AZ)",
                    "connection_type": "arrow",
                    "start_point": [800, 350],
                    "end_point": [800, 400]
                },
                {
                    "to_component_name": "Custom Components",
                    "connection_type": "arrow",
                    "start_point": [880, 350],
                    "end_point": [900, 400]
                },
                {
                    "to_component_name": "Models/Services",
                    "connection_type": "arrow",
                    "start_point": [900, 250],
                    "end_point": [1040, 250]
                },
                {
                    "to_component_name": "Amazon S3 (Backups)",
                    "connection_type": "arrow",
                    "start_point": [700, 350],
                    "end_point": [600, 470],
                    "compliance_added": true
                }
            ],
            "grouping": "Security group (private)",
            "annotations": [
                "2 Stage Docker Build",
                "GATE Studio Multiple containers",
                "Frontend REACT/VITE",
                "Python Build",
                "API Integration"
            ]
        },
        {
            "component_name": "Amazon ECR",
            "component_type": "storage",
            "label": "Amazon ECR",
            "bounding_box": [500, 350, 600, 400],
            "shape_type": "icon",
            "connections": [],
            "grouping": "Security group (private)",
            "annotations": []
        },
        {
            "component_name": "Amazon Auto Scaling Group",
            "component_type": "compute",
            "label": "Amazon Auto Scaling Group",
            "bounding_box": [650, 400, 750, 450],
            "shape_type": "icon",
            "connections": [
                {
                    "to_component_name": "Amazon S3 (Backups)",
                    "connection_type": "arrow",
                    "start_point": [700, 450],
                    "end_point": [600, 470],
                    "compliance_added": true
                }
            ],
            "grouping": "Security group (private)",
            "annotations": []
        },
        {
            "component_name": "Amazon RDS Postgres (Multi AZ)",
            "component_type": "database",
            "label": "Amazon RDS Postgres (Multi AZ)",
            "bounding_box": [770, 400, 870, 450],
            "shape_type": "icon",
            "connections": [],
            "grouping": "Security group (private)",
            "annotations": []
        },
        {
            "component_name": "Custom Components",
            "component_type": "compute",
            "label": "Custom Components",
            "bounding_box": [900, 400, 1000, 450],
            "shape_type": "icon",
            "connections": [
                {
                    "to_component_name": "Amazon S3 (Backups)",
                    "connection_type": "arrow",
                    "start_point": [950, 450],
                    "end_point": [600, 470],
                    "compliance_added": true
                }
            ],
            "grouping": "Security group (private)",
            "annotations": []
        },
        {
            "component_name": "Amazon S3 (Backups)",
            "component_type": "storage",
            "label": "Amazon S3 (Backups)",
            "bounding_box": [600, 470, 750, 520],
            "shape_type": "icon",
            "connections": [],
            "grouping": "Security group (private)",
            "annotations": ["Backups for all compute resources"],
            "compliance_added": true
        },
        {
            "component_name": "Models/Services",
            "component_type": "external_service",
            "label": "Models / Services",
            "bounding_box": [1040, 40, 1120, 540],
            "shape_type": "box",
            "connections": [],
            "grouping": "",
            "annotations": [
                "Azure Open AI",
                "AWS Bedrock",
                "NVIDIA Services",
                "Anthropic",
                "Cohere",
                "Langchain",
                "Google",
                "Hugging face"
            ]
        }
    ],
    "side_boxes": [
        {
            "label": "Data Scientist",
            "bounding_box": [120, 550, 220, 570]
        },
        {
            "label": "Developer",
            "bounding_box": [400, 550, 500, 570]
        },
        {
            "label": "Business Analyst",
            "bounding_box": [800, 550, 950, 570]
        }
    ],
    "legend": "The diagram uses colored boxes to represent subnets, security groups, and service types. Icons are used for AWS services and external providers. Arrows indicate data flow and integration. The rightmost vertical panel lists external AI/ML model providers under 'Models/Services'. User roles are annotated at the bottom for context. Components and connections marked with 'compliance_added' or 'compliance_modified' were added or changed to meet company guidelines."
}
```
**Summary of Compliance Additions/Modifications:**
- Added Imperva Firewall between WAF and ALB, with connections.
- Added Amazon S3 (Backups) in private subnet, with connections from all compute resources.
- Explicitly labeled security groups as "Security group (public)" and "Security group (private)".
- All changes are clearly marked for compliance.



Convert this JSON into a detailed, high-quality English prompt for DALL·E 3 to generate the corresponding architecture diagram image as DALL.E 3 prompt length is less.
'''


dalle_sys_prompt = """
You are a professional prompt engineer for generative AI. 
Your job is to convert a detailed, structured cloud architecture JSON description into a precise and detailed English prompt for a DALL·E 3 image generation model.

Instructions:
- The prompt must describe every component, its type, label, and position/region (if specified).
- Clearly specify all connections (arrows/lines) between components.
- Mention any groupings, clusters, or parent/child relationships.
- Note all important annotations, legends, or side boxes.
- Request the diagram to use standard cloud provider icons (e.g., AWS, Azure, GCP), clear labeled boxes, and arrows.
- Request a professional, clean, and readable style with a white background.
- Keep the prompt concise but fully descriptive; avoid including JSON or code.
- Output only the prompt for DALL·E 3.
"""