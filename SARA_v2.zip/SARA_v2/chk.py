import svgwrite

# Icon emoji placeholders (you can replace with SVG image hrefs)
icon_svg = {
    "aws_waf": "🛡️",         # Placeholder; in real code, use "icons/aws_waf.svg"
    "aws_alb": "⚖️",
    "aws_ecs": "🐳",
    "aws_rds": "🗄️",
    "aws_cloudwatch": "⏰",
    "generic_user": "👤"
}

def render_architecture(arch_json):
    dwg = svgwrite.Drawing(size=('800px', '400px'), profile='tiny')
    y_cursor = 60
    cluster_x = 120

    # Draw Internet leftmost
    dwg.add(dwg.text('👤', insert=(20, y_cursor), font_size=36))
    dwg.add(dwg.text('User', insert=(15, y_cursor + 35), font_size=16))

    # Draw VPC box
    dwg.add(dwg.rect(insert=(cluster_x, y_cursor-30), size=(620, 260), fill="#e5f7ff", stroke="#42aaff", rx=22, ry=22))
    dwg.add(dwg.text('VPC', insert=(cluster_x+12, y_cursor-8), font_size=18, fill="#2077aa"))

    # Public subnet
    dwg.add(dwg.rect(insert=(cluster_x+20, y_cursor), size=(260, 80), fill="#f6ffe5", stroke="#91c86c", rx=18, ry=18))
    dwg.add(dwg.text('Public subnet', insert=(cluster_x+32, y_cursor+18), font_size=14, fill="#447733"))
    # WAF
    dwg.add(dwg.text(icon_svg["aws_waf"], insert=(cluster_x+60, y_cursor+50), font_size=36))
    dwg.add(dwg.text('WAF', insert=(cluster_x+57, y_cursor+80), font_size=13))
    # ALB
    dwg.add(dwg.text(icon_svg["aws_alb"], insert=(cluster_x+170, y_cursor+50), font_size=36))
    dwg.add(dwg.text('ALB', insert=(cluster_x+168, y_cursor+80), font_size=13))
    # Arrow: WAF → ALB
    dwg.add(dwg.line(start=(cluster_x+95, y_cursor+55), end=(cluster_x+170, y_cursor+55), stroke="#444", stroke_width=2))

    # Private subnet
    y_cursor += 110
    dwg.add(dwg.rect(insert=(cluster_x+20, y_cursor), size=(260, 80), fill="#fffbe5", stroke="#eedb85", rx=18, ry=18))
    dwg.add(dwg.text('Private subnet', insert=(cluster_x+32, y_cursor+18), font_size=14, fill="#b8860b"))
    # ECS
    dwg.add(dwg.text(icon_svg["aws_ecs"], insert=(cluster_x+60, y_cursor+50), font_size=36))
    dwg.add(dwg.text('ECS', insert=(cluster_x+57, y_cursor+80), font_size=13))
    # RDS
    dwg.add(dwg.text(icon_svg["aws_rds"], insert=(cluster_x+170, y_cursor+50), font_size=36))
    dwg.add(dwg.text('RDS', insert=(cluster_x+168, y_cursor+80), font_size=13))
    # Arrow: ECS → RDS
    dwg.add(dwg.line(start=(cluster_x+95, y_cursor+55), end=(cluster_x+170, y_cursor+55), stroke="#444", stroke_width=2))

    # Draw connections: User → WAF
    dwg.add(dwg.line(start=(55, 90), end=(cluster_x+60, 90), stroke="#444", stroke_width=2))
    # ALB → ECS
    dwg.add(dwg.line(start=(cluster_x+195, y_cursor-60), end=(cluster_x+60, y_cursor+50), stroke="#444", stroke_width=2))

    # Monitoring & Logging sidebox
    dwg.add(dwg.rect(insert=(600, 80), size=(130, 80), fill="#f3f7fc", stroke="#555", rx=12, ry=12))
    dwg.add(dwg.text(icon_svg["aws_cloudwatch"], insert=(640, 130), font_size=36))
    dwg.add(dwg.text('CloudWatch', insert=(620, 170), font_size=13))

    # ALB → CloudWatch
    dwg.add(dwg.line(start=(cluster_x+170, 90), end=(600, 120), stroke="#a06bfa", stroke_width=2))

    return dwg.tostring()

# === Put your JSON here ===
arch_json = {
  "clusters": [
    {"name": "VPC", "contains": ["Public subnet", "Private subnet", "Monitoring & Logging"], "layout": "vertical"},
    {"name": "Public subnet", "contains": ["WAF", "ALB"], "layout": "horizontal"},
    {"name": "Private subnet", "contains": ["ECS Service", "RDS"], "layout": "horizontal"}
  ],
  "components": [
    {"name": "Internet", "type": "external", "icon_type": "generic_user", "label": "User", "inside": None, "relative_position": "outside VPC, left"},
    {"name": "WAF", "type": "security", "icon_type": "aws_waf", "label": "WAF", "inside": "Public subnet", "relative_position": "leftmost"},
    {"name": "ALB", "type": "networking", "icon_type": "aws_alb", "label": "ALB", "inside": "Public subnet", "relative_position": "right of WAF"},
    {"name": "ECS Service", "type": "compute", "icon_type": "aws_ecs", "label": "ECS Service", "inside": "Private subnet", "relative_position": "left"},
    {"name": "RDS", "type": "database", "icon_type": "aws_rds", "label": "RDS", "inside": "Private subnet", "relative_position": "right of ECS Service"},
    {"name": "CloudWatch", "type": "monitoring", "icon_type": "aws_cloudwatch", "label": "CloudWatch", "inside": "Monitoring & Logging", "relative_position": "center"}
  ],
  "connections": [
    {"from": "Internet", "to": "WAF", "type": "arrow"},
    {"from": "WAF", "to": "ALB", "type": "arrow"},
    {"from": "ALB", "to": "ECS Service", "type": "arrow"},
    {"from": "ECS Service", "to": "RDS", "type": "arrow"},
    {"from": "ALB", "to": "CloudWatch", "type": "arrow"}
  ],
  "side_boxes": [
    {"name": "Monitoring & Logging", "type": "sidebox", "label": "Monitoring & Logging", "contains": ["CloudWatch"], "position": "right outside VPC"}
  ]
}

# === Generate SVG and save to file ===
svg_code = render_architecture(arch_json)
with open("cloud_architecture.svg", "w", encoding="utf-8") as f:
    f.write(svg_code)
print("SVG diagram saved as 'cloud_architecture.svg'")
