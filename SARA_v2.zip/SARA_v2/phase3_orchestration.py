import json
import os
from openai import AzureOpenAI
from Prompts_template.phase3_prompt import phase_3_prompt,sys_prompt_phase3
api_base = "https://open-group.openai.azure.com/"
api_key= "6YHSyQC3kPpUjw4nCS3dNSujpX6gikZPRc17t0RfJeSSQUUehkhjJQQJ99BFACYeBjFXJ3w3AAABACOGxmk6"
deployment_name = 'gpt-4.1'
api_version = '2023-05-15' # this might change in the future

ICON_DIR=r"G:\SARA_v2\icons"
# ---- Step 1: Load Phase 1 Architecture JSON ----
PHASE1_JSON_PATH = 'arch_extracted_phase2.json'  # or whatever your file is called
with open(PHASE1_JSON_PATH, 'r', encoding='utf-8') as f:
    architecture_json = json.load(f)


extracted_arch_json_final=json.dumps(architecture_json)


def get_icon_types(icon_dir=ICON_DIR):
    return [f[:-4] for f in os.listdir(icon_dir) if f.endswith('.svg')]
res=get_icon_types(ICON_DIR)
icon_type_str = json.dumps(res)


phase3_base = phase_3_prompt.replace("{{icon_type_list here, e.g., ['aws_s3','aws_rds','azure_sql_database',...]}}", icon_type_str)
final_phse3_prompt = phase3_base.replace("{{Paste your final JSON here from phase2}}", extracted_arch_json_final)


from openai import AzureOpenAI
client = AzureOpenAI(
    azure_endpoint=api_base,
    api_key=api_key,
    api_version=api_version,

)

completion = client.chat.completions.create(
    model=deployment_name,
messages = [
    {"role": "system", "content":sys_prompt_phase3},
    {"role": "user", "content": final_phse3_prompt}
],max_tokens=20000,
    temperature=0
)

svg_output = completion.choices[0].message.content

# Save SVG to file
with open("architecture.svg", "w", encoding="utf-8") as f:
    f.write(svg_output)

print("SVG diagram saved as architecture.svg")

