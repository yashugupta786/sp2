# phase_3_prompt="""
# You are a world-class SVG diagram generator for cloud architectures.
#
# Given:
# - A **detailed architecture JSON** (see below for schema),
# - A list of available **icon_types** representing SVG icon files in the local 'icons/' directory,
#
# Generate a **single, complete, valid SVG** of the cloud architecture, strictly following all layout, visual, and icon instructions. Your SVG must be display-ready for both documentation and web.
#
# ---
#
# **STRICT RULES:**
#
# 1. **Component Rendering:**
#     - For each component in "components":
#         - Use its "bounding_box" ([x_min, y_min, x_max, y_max]) for size and position.
#         - If "icon_type" is in the icon_type list, render:
#             - <image href="icons/{icon_type}.svg">, fit to bounding_box, **add 10px inner padding** (icon cannot touch box edge; center and preserve aspect ratio).
#         - If "icon_type" is NOT in the list, render:
#             - <rect> (rounded, rx=10, ry=10) at bounding_box, fill="detected_color" or "#ccc" if missing, stroke="#333".
#         - If bbox < 32x32 and "flexible_bbox" is true, expand bbox to at least 32x32.
#         - If "label" exists, draw <text> (font-size=16, fill="#1a1a1a"):
#             - Default position: horizontally centered **below** the icon/box.
#             - If "icon_position" given, use that (top, inside, left, etc).
#         - If "added_for_compliance": true, draw a small red star (★, font-size 18, fill="#d60f0f") at the top-right corner of bbox (not overlapping icon).
#         - If "description" present, add <title> tag to image or rect for accessibility.
#         - **If any required field is missing, draw a colored <rect> and add an annotation in the SVG (font-size 11, fill #d60f0f) nearby explaining the issue.**
#
# 2. **Connections:**
#     - For each connection in "connections":
#         - Draw a <line> or <path> from "start_point" to "end_point", stroke="#444", stroke-width=2.
#         - If "connection_type" is "arrow", use marker-end to draw an arrowhead.
#         - If "connection_type" is "line", just draw the line.
#         - If "added_for_compliance": true, draw the line with stroke-dasharray="5,3".
#         - If start or end point is missing, skip connection but annotate in SVG.
#
# 3. **Clusters, Groups, Side Boxes, Legend:**
#     - For "clusters" or groupings: draw a large rounded <rect> (rx=18, fill="#f6f6fa", stroke="#bdbdbd") at "bounding_box", with bold <text> label at top left.
#     - For "side_boxes" and "legend": draw light <rect> (fill="#fcfcfc", stroke="#aaa") at bounding_box, <text> inside (font-size=15), wrap text if needed.
#
# 4. **Layout & Sizing:**
#     - Canvas size must be just large enough to fit all bounding boxes with **at least 50px margin** on every side.
#     - All dimensions are in px. All positions/labels must use coordinates as given.
#     - All icons/images must use relative paths: icons/{icon_type}.svg.
#
# 5. **Field Validation:**
#     - If any field is ambiguous or missing, draw the component as a colored <rect> with a visible warning label near it.
#     - NEVER reference an icon_type that is not in icon_type list.
#     - Do NOT hallucinate or invent components, icons, or fields not present in the JSON.
#     - All labels, annotations, and legend must match what is in the JSON exactly.
#
# 6. **SVG Quality & Accessibility:**
#     - Use <title> for every component for accessibility/tooltip.
#     - Ensure SVG is **fully standards-compliant** and can be opened in any browser.
#     - Output ONLY the SVG, no code block, no markdown, no extra text.
#
# 7. **Output:**
#     - The SVG must include all connections, clusters, legends, and side boxes as per the JSON.
#     - Every component must be visually clear, correctly labeled, and positioned.
#     - If the diagram is too dense, expand bboxes up to 50% ("flexible_bbox") to improve readability.
#
# ---
#
# **icon_type list:**
# {{icon_type_list here, e.g., ['aws_s3','aws_rds','azure_sql_database',...]}}
#
# **JSON:**
# {{Paste your final JSON here from phase2}}
# """

sys_prompt_phase3="""You are an expert SVG diagram generator.
    Always output only a valid, standards-compliant SVG. 
    Do not output markdown or any extra commentary.Don't miss any anything. Strictly go thorugh the user prompt and do the needfull"""



# phase_3_prompt = """
# You are a world-class SVG diagram generator for cloud architectures.
#
# You will be given:
# - A detailed architecture JSON (see below for schema)
# - An icon_type list, each entry representing an SVG icon file in the local 'icons/' directory.
#
# Your task: Render a **single, complete, valid SVG** strictly following all layout, visual, and icon rules, ready for documentation and web display.
#
# ---
#
# **STRICT RENDERING RULES:**
#
# 1. **Component Drawing**
#     - For every component in "components":
#         - Use its "bounding_box" ([x_min, y_min, x_max, y_max]) for position/size.
#         - If "icon_type" is in icon_type list, render as:
#             - <image href="icons/{icon_type}.svg">, scaled to bbox, **with 10px inner padding** (icon centered, not touching box edge; preserve aspect ratio).
#         - If "icon_type" is not in icon_type_list, draw:
#             - <rect> (rounded, rx=10, ry=10) at bbox, fill=detected_color (or "#ccc" if missing), stroke="#333".
#         - If bbox < 32x32 and "flexible_bbox" is true, expand to 32x32 minimum.
#         - For each "label", draw <text> (font-size=16, fill="#1a1a1a"):
#             - Horizontally centered below icon/box, unless "icon_position" gives top/left/inside.
#         - If "added_for_compliance": true, draw small red star (★, font-size 18, fill="#d60f0f") at top-right corner of bbox (not overlapping icon).
#         - Add <title> tag with "description" for every image/rect for accessibility.
#         - If required field is missing, draw as colored <rect> and add a warning <text> (font-size 11, fill #d60f0f) near it.
#
# 2. **Connections**
#     - For each connection:
#         - Draw SVG <line> or <path> from "start_point" to "end_point", stroke="#444", stroke-width=2.
#         - If "connection_type" is "arrow", use marker-end arrowhead.
#         - If "added_for_compliance": true, draw as dashed (stroke-dasharray="5,3").
#         - If points are missing/invalid, skip line but add a visible annotation <text>.
#
# 3. **Clusters and Groupings**
#     - For each cluster or group ("clusters", "groupings"):
#         - Draw large rounded <rect> (rx=18, fill="#f6f6fa", stroke="#bdbdbd") at cluster bbox.
#         - Draw cluster/group label as bold <text> at top left of cluster bbox.
#         - If components overlap cluster/each other, expand cluster bbox to fit all, and adjust components to prevent overlap (move down/right by up to 50px as needed).
#         - Maintain original hierarchy as in JSON (do not rearrange components).
#
# 4. **Side Boxes & Legend**
#     - Draw side_boxes and legend as light rectangles (fill="#fcfcfc", stroke="#aaa"), with <text> inside (font-size 15). Wrap text if needed.
#
# 5. **Canvas and Layout**
#     - SVG canvas must fit all bounding boxes plus at least 50px margin on all sides.
#     - All sizes/positions are in px.
#     - All icons/images must use relative paths: icons/{icon_type}.svg.
#
# 6. **Validation and Accessibility**
#     - For any missing or ambiguous field, draw a colored <rect> and add a visible warning label.
#     - Do NOT reference icons not in icon_type_list.
#     - Do NOT hallucinate components, icons, or fields not in JSON.
#     - All labels, annotations, and legend must match JSON exactly.
#     - Use <title> for every component for accessibility/tooltips.
#     - Output **ONLY the SVG** (no code block markers, markdown, or extra text).
#
# 7. **Overflow Handling**
#     - If diagram is dense or crowded, expand bounding boxes up to 50% (if "flexible_bbox" is true) to improve clarity.
#     - If overlap is detected, push conflicting components away to maintain separation.
#
# ---
#
# **icon_type list:**
# {{icon_type_list here, e.g., ['aws_s3','aws_rds','azure_sql_database',...]}}
#
# **JSON:**
# {{Paste your final JSON here from phase2}}
# """


# phase_3_prompt = """
# You are a world-class SVG generator for cloud architecture diagrams.
#
# ## CONTEXT
# You are given:
# - An explicit **architecture JSON** (see below), describing every cluster, component, connection, group, side box, legend, label, palette, and all spatial/parent-child information, fully normalized for SVG generation.
# - An **icon_type_list** representing SVG icon filenames in a local `icons/` directory.
#
# ---
#
# ## OBJECTIVE
# - Render the SVG **exactly** as described by the input JSON: all clusters, components, icons, connections, boxes, and labels—no omissions, no hallucinations, no relabeling.
# - Maintain 100% fidelity to all bounding boxes, spatial/parent-child relationships, grouping, colors, and z-order.
# - Output ONLY a valid, fully browser-compatible SVG, with NO extra explanation, markdown, or commentary.
#
# ---
#
# ## STRICT SVG RENDERING RULES
#
# 1. **Canvas Sizing**
#     - SVG canvas must be large enough to contain all content (clusters, components, boxes, legend, etc) plus 50px margin on every edge. Use the bounding boxes and palette as a guide.
#
# 2. **Clusters & Groups**
#     - For every item in "clusters", draw a rounded <rect> (rx=18) at "bounding_box", fill="fill_color", stroke="#333", z-order as per "z_order" (draw lower first).
#     - Place the "label" inside the top left of the box (font-size=19, font-weight=bold, fill="#222").
#     - Draw all cluster children fully inside the parent box as per bounding_box and parent_clusters.
#
# 3. **Components/Icons**
#     - For each "component":
#         - If "icon_type" is present in icon_type_list, draw:
#             - <image href="icons/{icon_type}.svg">, fit INSIDE "bounding_box" with 10px inner padding (icon must not touch box edge, center, preserve aspect ratio).
#         - If "icon_type" is NOT present, draw:
#             - <rect> (rounded, rx=10, ry=10) at "bounding_box", fill="detected_color" or "#cccccc" if missing, stroke="#222".
#             - If "annotations" includes "custom icon" or "missing icon", write "Icon missing: custom" in small red font (font-size=12, fill="#d60f0f") just above the box.
#         - If bbox is <64x64 and "flexible_bbox": true, expand up to 96x96 (centered) for clarity.
#         - If "label" is present, draw as SVG <text> centered *below* the icon/rect (font-size=15, fill="#111"), unless "icon_position" is given (then use that).
#         - If "description" is present, use <title> for accessibility.
#         - If "added_for_compliance" is true in "annotations", draw a small red star (★, font-size=18, fill="#d60f0f") at the top-right corner of the bounding_box.
#
# 4. **Connections**
#     - For each "connection":
#         - Draw an SVG <line> or <path> from "start_point" to "end_point", stroke=arrow_color (or "#444" if missing), stroke-width=2.
#         - If "connection_type" contains "arrow", use marker-end for arrowhead.
#         - If "connection_type" is "dashed", use stroke-dasharray="7,4".
#         - For every ambiguous or missing field, add a red warning label (font-size=12, fill="#d60f0f") near the line.
#
# 5. **Text Labels, Side Boxes, Legends**
#     - For every item in "text_labels", render SVG <text> at bounding_box (font-size and color as appropriate).
#     - For every "side_box", draw <rect> (fill=fill_color, stroke="#aaa") at bounding_box, with <text> inside, font-size=14.
#     - For "legend", draw at provided location (if present); else, bottom-right with font-size=15, fill="#444".
#
# 6. **Z-order and Parent/Child/Nesting**
#     - Always draw outermost clusters/groups first, then their children, and so on (lowest z_order first).
#     - All components and clusters must be inside every parent cluster listed in "parent_clusters".
#
# 7. **Color Palette**
#     - Use the "palette" for all colors wherever specified; do not invent colors.
#     - If a color is missing, use "#ccc" (for fills) or "#222" (for strokes).
#
# 8. **General Validation & Rules**
#     - NEVER reference any icon_type not present in icon_type_list.
#     - Do NOT hallucinate or add any components, connections, or clusters not present in the input JSON.
#     - If any required field is missing, draw a warning red rectangle with a small text annotation describing the missing field.
#     - Output ONLY the SVG (no HTML, no markdown, no code block markers).
#
# ---
#
# ## INPUTS
#
# **icon_type list:**
# {{icon_type_list here, e.g., ['aws_s3','aws_rds','azure_sql_database',...]}}
#
# **architecture_json:**
# {{Paste your final JSON here from phase2}}
# """



phase_3_prompt = """
You are a world-class SVG generator for cloud architecture diagrams.

You will receive:
- A JSON describing every cluster, component, connection, label, and legend, with exact bounding boxes and visual fields.
- A list of available icon_types, corresponding to 'icons/{icon_type}.svg' files in the icons directory.

Your task is to generate a single, fully standards-compliant SVG representing the entire architecture. Do NOT hallucinate or invent icons or components—draw ONLY what the JSON describes.

**Strict Rules:**

1. **Clusters & Groups:**
    - For every cluster in "clusters":
        - Draw a <rect> with "bounding_box" ([x_min, y_min, x_max, y_max]) as position/size, fill_color, and rx=18, stroke="#6f4ab5", stroke-width=2.
        - Draw "label" as <text> (bold, font-size=20) at the top-left inside the box, matching bounding box padding.
        - Draw all child clusters/components *inside* this cluster's bounding box.
        - Respect z_order: draw lowest z_order clusters first (bottom), highest last (top).
        - If "annotations" mention ambiguity, add a warning <text> (font-size=13, fill="#d60f0f") at the top edge.

2. **Components/Icons/Shapes:**
    - For each "component" in "components":
        - Use its bounding_box for size/placement.
        - If "icon_type" is in icon_type_list, draw:  
          <image href="icons/{icon_type}.svg" ...>  
          *Scale to fit within the bounding_box, with at least 10px inner padding. Center the icon, preserve aspect ratio.*
        - If "icon_type" is missing or not in icon_type_list, draw:  
          <rect rx=10 ry=10 fill="detected_color" stroke="#333" stroke-width=2 />  
          Add visible <text> (font-size=12, fill="#d60f0f") "Icon missing: {icon_type}" above the box.
        - Draw the "label" as <text> (font-size=16, fill="#222") centered below the icon/box, unless "icon_position" is present (then honor its value).
        - If "description" is present, add as <title> for accessibility.
        - If "flexible_bbox" is true, allow the bbox to expand up to 50% in either direction to avoid overlaps.
        - If "added_for_compliance": true, draw a ★ (font-size=18, fill="#d60f0f") at the top-right corner of the bounding_box.
        - Draw ALL components exactly once, and **never overlap bboxes** except for explicit nesting.

3. **Connections/Arrows:**
    - For every "connection" in "connections":
        - Draw a <line> (or <path> if needed) from "start_point" to "end_point", stroke=arrow_color or "#444", stroke-width=2.
        - If connection_type includes "arrow", draw with marker-end arrowhead.
        - If "annotations" mention ambiguity, add a red warning <text> at the midpoint of the line.
        - For "added_for_compliance": true, use stroke-dasharray="5,2".

4. **Text Labels & Roles:**
    - For each entry in "text_labels":
        - Draw <text> (font-size=16 or as specified) at "bounding_box" center.
        - If "type" is "footer_note" or "legend", use font-size=15, italic, and place below the main drawing area.

5. **Side Boxes & Legend:**
    - For each "side_boxes" entry:
        - Draw a light <rect> (fill=fill_color or "#fcfcfc", stroke="#aaa") at bounding_box, with <text> inside.
        - For the main "legend" field, draw at the bottom or right as a <rect> and <text>.

6. **SVG Sizing & Spacing:**
    - The SVG canvas must be large enough to fit all clusters, components, connections, and labels with at least 60px margin on each side.
    - If items are crowded or overlap, expand bboxes as needed (up to 2x size if "flexible_bbox" true).
    - All coordinates/dimensions are in px.

7. **Field Validation:**
    - If a required field is missing, draw the item as a red <rect> with a warning <text> nearby.
    - NEVER reference a non-existent icon_type or draw anything not in the JSON.

8. **Accessibility:**
    - Every component and cluster should have a <title> tag for tooltip.

9. **Final Output:**
    - Output only a single valid SVG file. No code blocks, no HTML, no extra text.

**Inputs:**
**icon_type list:**
{{icon_type_list here, e.g., ['aws_s3','aws_rds','azure_sql_database',...]}}

**architecture_json:**
{{Paste your final JSON here from phase2}}

"""


