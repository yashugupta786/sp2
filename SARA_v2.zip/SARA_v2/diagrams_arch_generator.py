from diagrams import Diagram, Cluster
from diagrams.aws.iot import IotCore
from diagrams.aws.general import User
from diagrams.aws.compute import Lambda, ECS
from diagrams.aws.integration import APIGateway
from diagrams.aws.database import Dynamodb, Timestream
from diagrams.aws.network import PrivateLink
from diagrams.aws.storage import S3
from diagrams.aws.analytics import ManagedStreamingForKafka
from diagrams.aws.mobile import Amplify
from diagrams.aws.security import Cognito
from diagrams.aws.network import CloudFront

# Start diagram
with Diagram("AWS Connected Car Architecture", show=False, direction="LR"):
    with Cluster("Connected Car"):
        car = User("vehicle gateway\nMQTT/OpenSSL libraries")

    plink = PrivateLink("AWS PrivateLink\nVPC endpoint")
    iotcore = IotCore("AWS IoT Core")

    with Cluster("AWS Cloud"):
        # Remote Commands
        with Cluster("Remote Commands\n(request/response)"):
            req_topic = S3("request IoT topic")
            resp_topic = S3("response IoT topic")
            lambda1 = Lambda("Lambda 1")
            dynamodb1 = Dynamodb("DynamoDB 1")
            lambda2 = Lambda("Lambda 2")
            apigw1 = APIGateway("API Gateway 1")
            amplify1 = Amplify("Amplify 1")

        # Data Ingest
        with Cluster("Data Ingest\n(shared subscription)"):
            telemetry_topic = S3("vehicle telemetry topic")
            ecs = ECS("ECS\ncontainers")
            kafka = ManagedStreamingForKafka("Managed Kafka")
            lambda3 = Lambda("Lambda 3")
            apigw2 = APIGateway("API Gateway 2")

        # Routing Messages
        with Cluster("Routing Messages\n(user properties)"):
            iot_topic = S3("IoT topic")
            ecs2 = ECS("containers")
            timestream = Timestream("Timestream")
            s3_1 = S3("S3 Storage")

        # Device Control
        with Cluster("Device Control\n(session expiry)"):
            cmd_topic = S3("command IoT topic")
            lambda4 = Lambda("Lambda 4")
            dynamodb2 = Dynamodb("DynamoDB 2")
            lambda5 = Lambda("Lambda 5")

        # Critical Commands
        with Cluster("Critical Commands\n(retained messages)"):
            crit_topic = S3("critical command topic")
            lambda6 = Lambda("Lambda 6")
            dynamodb3 = Dynamodb("DynamoDB 3")
            lambda7 = Lambda("Lambda 7")
            apigw3 = APIGateway("API Gateway 3")

        # Data Visualization
        with Cluster("Data Visualization"):
            s3_2 = S3("S3 Data Lake")
            cloudfront = CloudFront("CloudFront")
            cognito = Cognito("Cognito")
            amplify2 = Amplify("Amplify 2")

    # Applications
    comp_app = User("companion application")
    owner = User("vehicle owner")
    mgmt_platform = User("vehicle management platform")

    # Main Connections
    car >> plink >> iotcore

    # Remote commands
    iotcore >> req_topic >> lambda1 >> dynamodb1 >> lambda2 >> apigw1 >> amplify1 >> comp_app >> owner
    iotcore >> resp_topic

    # Data ingest
    iotcore >> telemetry_topic >> ecs >> kafka >> lambda3 >> apigw2 >> s3_2
    s3_2 >> cloudfront >> cognito >> amplify2

    # Routing messages
    iotcore >> iot_topic >> ecs2
    ecs2 >> timestream
    ecs2 >> s3_1

    # Device control
    iotcore >> cmd_topic >> lambda4 >> dynamodb2 >> lambda5

    # Critical commands
    iotcore >> crit_topic >> lambda6 >> dynamodb3 >> lambda7 >> apigw3 >> mgmt_platform
