import json
import os
from openai import AzureOpenAI
from Prompts_template.phase2_prompt import company_guidelines,phase2_prompt,system_prompt
api_base = "https://open-group.openai.azure.com/"
api_key= "6YHSyQC3kPpUjw4nCS3dNSujpX6gikZPRc17t0RfJeSSQUUehkhjJQQJ99BFACYeBjFXJ3w3AAABACOGxmk6"
deployment_name = 'gpt-4.1'
api_version = '2023-05-15' # this might change in the future

ICON_DIR=r"G:\SARA_v2\icons"
from Prompts_template.phase2_prompt import company_guidelines,phase2_prompt
# ---- Step 1: Load Phase 1 Architecture JSON ----
PHASE1_JSON_PATH = 'arch_extracted.json'  # or whatever your file is called
with open(PHASE1_JSON_PATH, 'r', encoding='utf-8') as f:
    architecture_json = json.load(f)

extracted_arch_json=json.dumps(architecture_json)
def get_icon_types(icon_dir=ICON_DIR):
    return [f[:-4] for f in os.listdir(icon_dir) if f.endswith('.svg')]
res=get_icon_types(ICON_DIR)
icon_type_str = json.dumps(res)
base_sara_promt_template = phase2_prompt.replace("{{icon_type_list here, e.g., ['aws_s3','aws_rds','azure_sql_database',...]}}", icon_type_str)
base_sara_promt_template_arch = base_sara_promt_template.replace("{{architecture_json here from phase1}}", extracted_arch_json)
final_phse2_prompt = base_sara_promt_template_arch.replace("{{company_guidelines here for reverification}}", company_guidelines)
print(final_phse2_prompt)



from openai import AzureOpenAI
client = AzureOpenAI(
    azure_endpoint=api_base,
    api_key=api_key,
    api_version=api_version,

)

completion = client.chat.completions.create(
    model=deployment_name,
messages = [
    {"role": "system", "content":system_prompt},
    {"role": "user", "content": final_phse2_prompt}
],max_tokens=20000,
    temperature=0
)

l=completion.json()
p=json.loads(l)
final_out=p["choices"][0]["message"]["content"]
arch_json=json.loads(final_out)

def save_json(data, fname):
    with open(fname, "w") as f:
        f.write(json.dumps(data, indent=2))

save_json(arch_json, "arch_extracted_phase2.json")


