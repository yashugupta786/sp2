import os
import json
from PIL import Image, ImageEnhance
import base64
from Prompts_template.base_prompt import sara_base_prompt
from mimetypes import guess_type
from openai import AzureOpenAI
api_base = "https://open-group.openai.azure.com/"
api_key= "6YHSyQC3kPpUjw4nCS3dNSujpX6gikZPRc17t0RfJeSSQUUehkhjJQQJ99BFACYeBjFXJ3w3AAABACOGxmk6"
deployment_name = 'gpt-4.1'
api_version = '2023-05-15' # this might change in the future

ICON_DIR=r"G:\SARA_v2\icons"

def get_icon_types(icon_dir=ICON_DIR):
    return [f[:-4] for f in os.listdir(icon_dir) if f.endswith('.svg')]
res=get_icon_types(ICON_DIR)



def enhance_image(input_path, output_path, sharpness=2, contrast=1.5, brightness=1.1):
    img = Image.open(input_path).convert("RGB")
    img = ImageEnhance.Sharpness(img).enhance(sharpness)
    img = ImageEnhance.Contrast(img).enhance(contrast)
    img = ImageEnhance.Brightness(img).enhance(brightness)
    img.save(output_path)
    print(f"Enhanced image saved as {output_path}")

enhance_image(r"G:\SARA_v2\images\input_image.png", "output_enhance.png")




def local_image_to_data_url(image_path):
    # Guess the MIME type of the image based on the file extension
    mime_type, _ = guess_type(image_path)
    if mime_type is None:
        mime_type = 'application/octet-stream'  # Default MIME type if none is found

    # Read and encode the image file
    with open(image_path, "rb") as image_file:
        base64_encoded_data = base64.b64encode(image_file.read()).decode('utf-8')

    # Construct the data URL
    return f"data:{mime_type};base64,{base64_encoded_data}"


image_path = r"G:\SARA_v2\output_enhance.png"
data_url = local_image_to_data_url(image_path)\

icon_type_str = json.dumps(res)
base_sara_promt_template = sara_base_prompt.replace("{{icon_type_list here, e.g., ['aws_s3','aws_rds','azure_sql_database',...]}}", icon_type_str)
# print(base_sara_promt_template)


client = AzureOpenAI(
    api_key=api_key,
    api_version=api_version,
    base_url=f"{api_base}/openai/deployments/{deployment_name}"
)

response = client.chat.completions.create(
    model=deployment_name,
max_tokens=20000,
temperature=0,
    messages=[
        { "role": "system", "content": base_sara_promt_template },
        { "role": "user", "content": [
            {
                "type": "text",
                "text": "Strictly Analyze the following image for architecture extraction with details provided in system prompt."
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": data_url
                }
            }
        ] }
    ],

)
l=response.json()
p=json.loads(l)
final_out=p["choices"][0]["message"]["content"]
arch_json=json.loads(final_out)

def save_json(data, fname):
    with open(fname, "w") as f:
        f.write(json.dumps(data, indent=2))

save_json(arch_json, "arch_extracted.json")
