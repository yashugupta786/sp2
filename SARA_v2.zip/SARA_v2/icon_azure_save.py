import os
import shutil

# Set these paths!
AZURE_ICONS_ROOT = r'G:\SARA_v2\Architecture-Group-Icons_02072025'  # The folder with all the Azure subfolders
TARGET_ICONS_DIR = r'G:\SARA_v2\aws_icons_flat'    # Your unified icons folder

os.makedirs(TARGET_ICONS_DIR, exist_ok=True)

for root, dirs, files in os.walk(AZURE_ICONS_ROOT):
    for file in files:
        if file.endswith('.svg'):
            # Make a unique name: combine folder name (parent) and filename
            rel_dir = os.path.relpath(root, AZURE_ICONS_ROOT)
            # Replace " " and "+" with "_" for safe filenames
            prefix = rel_dir.replace(" ", "_").replace("+", "plus").replace("\\", "_").replace("/", "_")
            if prefix == ".":
                prefix = "aws"
            new_filename = f"aws_{prefix}_{file}" if prefix else f"aws{file}"
            src = os.path.join(root, file)
            dst = os.path.join(TARGET_ICONS_DIR, new_filename)
            shutil.copy2(src, dst)
            print(f"Copied {src} to {dst}")

print("✅ All Azure SVG icons have been copied to:", TARGET_ICONS_DIR)
